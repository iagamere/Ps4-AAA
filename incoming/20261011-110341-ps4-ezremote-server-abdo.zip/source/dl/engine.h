// Download engine for the custom ezRemote Server.
//  - thread-safe download list (the original used an unguarded std::vector and a raw pointer into it)
//  - parallel queue, per-download pause / resume / delete without touching other downloads
//  - automatic multi-connection (chunked Range) downloading with a hill-climbing tuner
//  - completion validation (HTTP status, content type, final size) and atomic persistence
// The engine has no PS4-specific code: the platform glue is injected through Hooks.
#ifndef DL_ENGINE_H
#define DL_ENGINE_H

#include <cstdint>
#include <functional>
#include <string>
#include <vector>
#include "dl/minijson.h"

namespace DL
{
    // numeric values of the original ezRemote enum DownloadState are kept for 0..4
    enum State
    {
        ST_PENDING = 0,
        ST_DOWNLOADING = 1,
        ST_RESUMED = 2,
        ST_FAILED = 3,
        ST_SUCCESS = 4,
        ST_PAUSED = 5,     // legacy API reports this as FAILED (3)
        ST_NEEDS_LINK = 6, // legacy API reports this as FAILED (3)
        ST_STOPPING = 7    // legacy API reports this as DOWNLOADING (1)
    };

    struct Settings
    {
        int max_parallel = 2;           // downloads running at the same time
        int max_conns_per_download = 8; // ceiling for the automatic tuner
        int max_total_conns = 12;       // ceiling over all downloads (protects the PS4 memory)
        bool auto_conns = true;         // false: always use fixed_conns
        int fixed_conns = 4;
        int chunk_mb = 16;
        int max_attempts = 0;           // consecutive failed attempts before giving up; 0 = never give up on transient errors
        bool notify_start = false;
        bool notify_complete = true;
        bool notify_fail = true;
        bool preempt = true; // a pending download with a higher priority pauses the lowest-priority running one when all slots are busy
        // optional allow-list of destination folders (absolute prefixes). Empty = any absolute path, like before.
        std::vector<std::string> dest_roots;
        std::string token; // optional: required in header X-Token for /v2 routes (and /stop)
    };

    struct Host
    {
        int type = 0;
        std::string url;
        std::string http_server_type;
        std::string username;
        std::string password;
    };

    // Downloads that are not plain HTTP file-host downloads (FTP, SMB, NFS, SFTP, WebDAV, HTTP servers) still go
    // through the original RemoteClient classes. They share global state, so they run one at a time.
    struct LegacyJob
    {
        Host host;
        std::string src_path;
        std::string tmp_path;
        uint64_t offset = 0;
        uint64_t *progress = nullptr;             // write total bytes here
        const volatile bool *cancel = nullptr;    // abort when true
        std::string error;                        // out
    };

    struct Hooks
    {
        std::function<void(const std::string &)> notify;
        std::function<int(LegacyJob &)> legacy_get; // 1 = ok
        std::function<std::string(const std::string &)> encrypt; // identity when empty
        std::function<std::string(const std::string &)> decrypt;
        std::function<int64_t(const std::string &)> free_bytes; // free bytes of the volume holding a path; -1 = unknown (optional)
        int filehost_type = 7; // CLIENT_TYPE_FILEHOST
    };

    void Init(const std::string &data_dir, const Hooks &hooks);
    void Start();    // loads state, starts the scheduler
    void Shutdown(); // stops everything and saves
    void SetRestMode(bool rest);

    struct AddResult
    {
        bool ok = false;
        bool updated = false; // an existing download for the same destination received the new link
        uint32_t uid = 0;
        std::string error;
    };
    AddResult Add(const Host &host, const std::string &src_path, const std::string &dest_path, uint64_t size, uint64_t orig_id,
                  int priority = 0, bool to_top = false);

    // ---- queue order and priority ----
    // priority: -100..100 (higher first, default 0). Order inside the same priority is the list order (oldest first).
    bool SetPriority(uint32_t uid, int priority, std::string &err);
    // where: "top", "bottom", "up", "down" or "pos" (0-based index in the list, given in position)
    bool Move(uint32_t uid, const std::string &where, int position, std::string &err, int &new_position);
    // moves the download to the top, gives it a priority above all others and resumes it when stopped
    bool StartNow(uint32_t uid, std::string &err);
    // token stored in <data_dir>/dlserver_settings.json (readable before Init/Start); "" when none
    std::string StoredToken(const std::string &data_dir);

    bool Pause(uint32_t uid, std::string &err);
    bool Resume(uint32_t uid, std::string &err); // also "retry"
    // delete_files: remove the partial file (and the finished file when the download had completed)
    bool Remove(uint32_t uid, bool delete_files, std::string &err);
    int PauseAll();
    int ResumeAll();

    // legacy = the format of the original GET /get_download_state
    mj::Json ListJson(bool legacy);
    mj::Json InfoJson();
    Settings GetSettings();
    bool UpdateSettings(const mj::Json &j, std::string &err);
    std::string LogTail(int lines);
    void Log(const char *fmt, ...);

    extern const char *kVersion;       // real version of this server
    extern const char *kCompatVersion; // what the unmodified ezRemote Client expects from GET /version
}

#endif
