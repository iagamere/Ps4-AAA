// Minimal, dependency-free JSON value with a tolerant parser and a writer.
// Used by the download engine so that a corrupt bg_download_history.json can never crash the server
// (the original code dereferenced a null json-c object).
#ifndef DL_MINIJSON_H
#define DL_MINIJSON_H

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <utility>
#include <vector>

namespace mj
{
    struct Json
    {
        enum Type { Null, Bool, Int, Real, Str, Arr, Obj };
        Type t = Null;
        bool b = false;
        int64_t i = 0;
        double d = 0;
        std::string s;
        std::vector<Json> a;
        std::vector<std::pair<std::string, Json>> o;

        Json() {}
        static Json object() { Json j; j.t = Obj; return j; }
        static Json array() { Json j; j.t = Arr; return j; }
        static Json str(const std::string &v) { Json j; j.t = Str; j.s = v; return j; }
        static Json num(int64_t v) { Json j; j.t = Int; j.i = v; return j; }
        static Json real(double v) { Json j; j.t = Real; j.d = v; return j; }
        static Json boolean(bool v) { Json j; j.t = Bool; j.b = v; return j; }

        Json &set(const std::string &k, const Json &v)
        {
            for (auto &p : o)
                if (p.first == k) { p.second = v; return *this; }
            o.emplace_back(k, v);
            return *this;
        }
        Json &push(const Json &v) { a.push_back(v); return *this; }

        const Json *get(const std::string &k) const
        {
            if (t != Obj) return nullptr;
            for (auto &p : o)
                if (p.first == k) return &p.second;
            return nullptr;
        }
        std::string getStr(const std::string &k, const std::string &def = "") const
        {
            const Json *v = get(k);
            if (!v) return def;
            if (v->t == Str) return v->s;
            if (v->t == Int) return std::to_string(v->i);
            return def;
        }
        int64_t getInt(const std::string &k, int64_t def = 0) const
        {
            const Json *v = get(k);
            if (!v) return def;
            if (v->t == Int) return v->i;
            if (v->t == Real) return (int64_t)v->d;
            if (v->t == Bool) return v->b ? 1 : 0;
            if (v->t == Str) return (int64_t)strtoll(v->s.c_str(), nullptr, 10);
            return def;
        }
        bool getBool(const std::string &k, bool def = false) const
        {
            const Json *v = get(k);
            if (!v) return def;
            if (v->t == Bool) return v->b;
            if (v->t == Int) return v->i != 0;
            if (v->t == Str) return v->s == "true" || v->s == "1";
            return def;
        }

        // ---------------- writer ----------------
        static void escape(const std::string &in, std::string &out)
        {
            out += '"';
            for (unsigned char c : in)
            {
                switch (c)
                {
                case '"': out += "\\\""; break;
                case '\\': out += "\\\\"; break;
                case '\n': out += "\\n"; break;
                case '\r': out += "\\r"; break;
                case '\t': out += "\\t"; break;
                default:
                    if (c < 0x20)
                    {
                        char buf[8];
                        snprintf(buf, sizeof(buf), "\\u%04x", c);
                        out += buf;
                    }
                    else
                        out += (char)c;
                }
            }
            out += '"';
        }
        void write(std::string &out) const
        {
            switch (t)
            {
            case Null: out += "null"; break;
            case Bool: out += b ? "true" : "false"; break;
            case Int: out += std::to_string((long long)i); break;
            case Real:
            {
                char buf[48];
                snprintf(buf, sizeof(buf), "%.3f", d);
                out += buf;
                break;
            }
            case Str: escape(s, out); break;
            case Arr:
                out += '[';
                for (size_t k = 0; k < a.size(); k++)
                {
                    if (k) out += ',';
                    a[k].write(out);
                }
                out += ']';
                break;
            case Obj:
                out += '{';
                for (size_t k = 0; k < o.size(); k++)
                {
                    if (k) out += ',';
                    escape(o[k].first, out);
                    out += ':';
                    o[k].second.write(out);
                }
                out += '}';
                break;
            }
        }
        std::string dump() const
        {
            std::string r;
            write(r);
            return r;
        }

        // ---------------- parser ----------------
        static bool parse(const std::string &text, Json &out)
        {
            Parser p{text.c_str(), text.c_str() + text.size(), 0};
            p.ws();
            if (!p.value(out)) return false;
            p.ws();
            return true;
        }

    private:
        struct Parser
        {
            const char *p;
            const char *e;
            int depth;
            void ws()
            {
                while (p < e && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++;
            }
            bool lit(const char *w)
            {
                size_t n = strlen(w);
                if ((size_t)(e - p) >= n && strncmp(p, w, n) == 0) { p += n; return true; }
                return false;
            }
            static void utf8(unsigned cp, std::string &o)
            {
                if (cp < 0x80) o += (char)cp;
                else if (cp < 0x800) { o += (char)(0xC0 | (cp >> 6)); o += (char)(0x80 | (cp & 0x3F)); }
                else if (cp < 0x10000) { o += (char)(0xE0 | (cp >> 12)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
                else { o += (char)(0xF0 | (cp >> 18)); o += (char)(0x80 | ((cp >> 12) & 0x3F)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
            }
            bool hex4(unsigned &v)
            {
                if (e - p < 4) return false;
                v = 0;
                for (int k = 0; k < 4; k++)
                {
                    char c = *p++;
                    v <<= 4;
                    if (c >= '0' && c <= '9') v |= c - '0';
                    else if (c >= 'a' && c <= 'f') v |= c - 'a' + 10;
                    else if (c >= 'A' && c <= 'F') v |= c - 'A' + 10;
                    else return false;
                }
                return true;
            }
            bool string(std::string &r)
            {
                if (p >= e || *p != '"') return false;
                p++;
                while (p < e)
                {
                    char c = *p++;
                    if (c == '"') return true;
                    if (c != '\\') { r += c; continue; }
                    if (p >= e) return false;
                    char x = *p++;
                    switch (x)
                    {
                    case '"': r += '"'; break;
                    case '\\': r += '\\'; break;
                    case '/': r += '/'; break;
                    case 'b': r += '\b'; break;
                    case 'f': r += '\f'; break;
                    case 'n': r += '\n'; break;
                    case 'r': r += '\r'; break;
                    case 't': r += '\t'; break;
                    case 'u':
                    {
                        unsigned cp;
                        if (!hex4(cp)) return false;
                        if (cp >= 0xD800 && cp < 0xDC00 && e - p >= 6 && p[0] == '\\' && p[1] == 'u')
                        {
                            p += 2;
                            unsigned lo;
                            if (!hex4(lo)) return false;
                            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                        }
                        utf8(cp, r);
                        break;
                    }
                    default: return false;
                    }
                }
                return false;
            }
            bool value(Json &out)
            {
                if (p >= e || depth > 64) return false;
                char c = *p;
                if (c == '{')
                {
                    p++;
                    depth++;
                    out = Json::object();
                    ws();
                    if (p < e && *p == '}') { p++; depth--; return true; }
                    while (true)
                    {
                        ws();
                        std::string k;
                        if (!string(k)) return false;
                        ws();
                        if (p >= e || *p != ':') return false;
                        p++;
                        ws();
                        Json v;
                        if (!value(v)) return false;
                        out.o.emplace_back(k, v);
                        ws();
                        if (p < e && *p == ',') { p++; continue; }
                        if (p < e && *p == '}') { p++; break; }
                        return false;
                    }
                    depth--;
                    return true;
                }
                if (c == '[')
                {
                    p++;
                    depth++;
                    out = Json::array();
                    ws();
                    if (p < e && *p == ']') { p++; depth--; return true; }
                    while (true)
                    {
                        ws();
                        Json v;
                        if (!value(v)) return false;
                        out.a.push_back(v);
                        ws();
                        if (p < e && *p == ',') { p++; continue; }
                        if (p < e && *p == ']') { p++; break; }
                        return false;
                    }
                    depth--;
                    return true;
                }
                if (c == '"') { out.t = Str; return string(out.s); }
                if (lit("true")) { out.t = Bool; out.b = true; return true; }
                if (lit("false")) { out.t = Bool; out.b = false; return true; }
                if (lit("null")) { out.t = Null; return true; }
                // number
                const char *st = p;
                bool isReal = false;
                if (p < e && (*p == '-' || *p == '+')) p++;
                while (p < e && ((*p >= '0' && *p <= '9') || *p == '.' || *p == 'e' || *p == 'E' || *p == '-' || *p == '+'))
                {
                    if (*p == '.' || *p == 'e' || *p == 'E') isReal = true;
                    p++;
                }
                if (p == st) return false;
                std::string n(st, p - st);
                if (isReal) { out.t = Real; out.d = strtod(n.c_str(), nullptr); }
                else { out.t = Int; out.i = (int64_t)strtoll(n.c_str(), nullptr, 10); }
                return true;
            }
        };
    };
}

#endif
