#ifndef DL_API_H
#define DL_API_H
#include "http/httplib.h"

namespace DL
{
    // Registers the download routes on an httplib server:
    //   legacy (unchanged contract): POST /download_url, GET /get_download_state, GET /version
    //   new:  GET /v2/info, /v2/downloads, /v2/log; POST /v2/add, /v2/pause, /v2/resume, /v2/delete, /v2/settings,
    //         /v2/priority, /v2/move, /v2/start_now
    //   Cross-site browser requests (Origin / Sec-Fetch-Site) are rejected on every route.
    void RegisterRoutes(httplib::Server &svr);

    // true when no token is configured or the request carries the right X-Token header; otherwise answers 401 and returns false
    bool Authorized(const httplib::Request &req, httplib::Response &res);
}
#endif
