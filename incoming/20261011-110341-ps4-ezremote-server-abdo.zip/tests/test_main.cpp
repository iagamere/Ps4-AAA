// Linux test host: the download engine + its HTTP API, without any PS4 code.
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <sys/vfs.h>
#include <unistd.h>
#include "dl/api.h"
#include "dl/engine.h"

static httplib::Server *g_svr;
static void on_sig(int) { if (g_svr) g_svr->stop(); }

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s <data_dir> <port>\n", argv[0]); return 2; }
    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
    DL::Hooks h;
    h.notify = [](const std::string &m) { printf("NOTIFY: %s\n", m.c_str()); fflush(stdout); };
    h.free_bytes = [](const std::string &d) -> int64_t { struct statfs sf; return statfs(d.c_str(), &sf) == 0 ? (int64_t)((uint64_t)sf.f_bavail * sf.f_bsize) : -1; };
    // fake FTP/SMB/NFS-style transfer: takes 6 seconds, honours cancel, writes a tiny file
    h.legacy_get = [](DL::LegacyJob &job) -> int {
        for (int i = 0; i < 60; i++)
        {
            if (job.cancel && *job.cancel) return 0;
            usleep(100000);
        }
        FILE *f = fopen(job.tmp_path.c_str(), "wb");
        if (!f) return 0;
        fputs("legacy", f);
        fclose(f);
        if (job.progress) *job.progress = 6;
        return 1;
    };
    DL::Init(argv[1], h);
    DL::Start();
    httplib::Server svr;
    g_svr = &svr;
    DL::RegisterRoutes(svr);
    svr.Get("/stop", [&](const httplib::Request &req, httplib::Response &res) {
        if (!DL::Authorized(req, res)) return;   // same guard as the real /stop route
        svr.stop();
    });
    svr.listen("127.0.0.1", atoi(argv[2]));
    DL::Shutdown();
    return 0;
}
