#!/usr/bin/env python3
"""Throttled test origin: Range support, per-connection and global bandwidth caps, and failure modes."""
import sys, time, threading, random, hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PER_CONN = float(sys.argv[2]) * 1048576 if len(sys.argv) > 2 else 4 * 1048576
TOTAL = float(sys.argv[3]) * 1048576 if len(sys.argv) > 3 else 40 * 1048576
BLK = 65536
random.seed(1234)
BASE = bytes(random.getrandbits(8) for _ in range(BLK))
TABLES = [bytes((i ^ (n % 251)) for i in range(256)) for n in range(251)]
BLOCKS = [BASE.translate(TABLES[n]) for n in range(251)]

def content(off, length):
    out = []
    end = off + length
    while off < end:
        b = off // BLK
        s = off % BLK
        blk = BLOCKS[b % 251]
        take = min(end - off, BLK - s)
        out.append(blk[s:s + take])
        off += take
    return b"".join(out)

lock = threading.Lock()
OUTAGE = {}
active = 0
max_active = 0
bucket = [TOTAL, time.time()]

def take_tokens(n):
    while True:
        with lock:
            now = time.time()
            bucket[0] = min(TOTAL, bucket[0] + (now - bucket[1]) * TOTAL)
            bucket[1] = now
            if bucket[0] >= n:
                bucket[0] -= n
                return
        time.sleep(0.005)

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass

    def do_GET(self):
        global active, max_active
        u = urlparse(self.path)
        q = parse_qs(u.query)
        size = int(q.get("size", ["64"])[0]) * 1048576
        if u.path == "/stats":
            body = ("max_active=%d\n" % max_active).encode()
            self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
        if u.path == "/html":
            body = b"<html>quota exceeded</html>"
            self.send_response(200); self.send_header("Content-Type", "text/html"); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body); return
        if u.path == "/outage":
            # the whole host answers 503 for the first N seconds after the first request, then works
            secs = int(q.get("secs", ["60"])[0])
            with lock:
                if "outage_start" not in OUTAGE: OUTAGE["outage_start"] = time.time()
                down = time.time() - OUTAGE["outage_start"] < secs
            if down:
                self.send_response(503); self.send_header("Content-Length", "0"); self.end_headers(); return
        if u.path == "/expired":
            self.send_response(403); self.send_header("Content-Length", "0"); self.end_headers(); return
        with lock:
            active += 1
            max_active = max(max_active, active)
            my_active = active
        try:
            if u.path == "/refuse_parallel" and my_active > 1:
                self.send_response(403); self.send_header("Content-Length", "0"); self.end_headers(); return
            rng = self.headers.get("Range")
            a, b = 0, size - 1
            status = 200
            if rng and u.path != "/norange":
                spec = rng.split("=")[1]
                s, e = spec.split("-")
                a = int(s)
                b = int(e) if e else size - 1
                b = min(b, size - 1)
                if a >= size:
                    self.send_response(416); self.send_header("Content-Length", "0"); self.end_headers(); return
                status = 206
            length = b - a + 1
            self.send_response(status)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(length))
            self.send_header("Accept-Ranges", "bytes")
            if status == 206:
                self.send_header("Content-Range", "bytes %d-%d/%d" % (a, b, size))
            self.end_headers()
            drop_at = None
            if u.path == "/flaky" and length > 4 * 1048576 and random.random() < 0.3:
                drop_at = random.randint(1, length - 1)
            sent = 0
            pos = a
            t_next = time.time()
            while sent < length:
                n = min(BLK, length - sent)
                if drop_at is not None and sent + n > drop_at:
                    n = drop_at - sent
                    self.wfile.write(content(pos, n)); self.wfile.flush()
                    self.close_connection = True
                    try: self.connection.shutdown(2)
                    except Exception: pass
                    return
                take_tokens(n)
                self.wfile.write(content(pos, n))
                sent += n; pos += n
                t_next += n / PER_CONN
                d = t_next - time.time()
                if d > 0: time.sleep(d)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            with lock:
                active -= 1

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
