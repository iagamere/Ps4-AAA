#!/usr/bin/env python3
import json, os, shutil, signal, subprocess, sys, time, urllib.request, tempfile
sys.path.insert(0, os.path.dirname(__file__))
import origin as O

HOST = "http://127.0.0.1:7701"
BIN = sys.argv[1]
PER, TOTAL = sys.argv[2], sys.argv[3]
work = tempfile.mkdtemp(prefix="dltest")
data = os.path.join(work, "data"); out = os.path.join(work, "out")
os.makedirs(data); os.makedirs(out)
procs = []

def start_origin():
    p = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), "origin.py"), "7702", PER, TOTAL]); procs.append(p); time.sleep(1.0); return p
def start_server():
    p = subprocess.Popen([BIN, data, "7701"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True); procs.append(p); time.sleep(0.8); return p
def stop(p):
    p.send_signal(signal.SIGTERM)
    try: p.wait(10)
    except Exception: p.kill()
def req(path, body=None, method=None):
    r = urllib.request.Request(HOST + path, data=(json.dumps(body).encode() if body is not None else None), method=method)
    try:
        with urllib.request.urlopen(r, timeout=10) as f: return f.status, f.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
def jreq(path, body=None):
    s, t = req(path, body, "POST" if body is not None else None)
    return s, json.loads(t) if t.strip().startswith(("{", "[")) else t
def add(name, urlpath, size_mb=0, legacy=False):
    body = {"type": 7, "url": "http://127.0.0.1:7702", "src_path": urlpath, "dest_path": os.path.join(out, name), "size": size_mb << 20, "id": 1}
    return jreq("/download_url" if legacy else "/v2/add", body)
def dls(): return jreq("/v2/downloads")[1]["downloads"]
def get(i): 
    for d in dls():
        if d["id"] == i: return d
def wait(i, states, timeout):
    t0 = time.time()
    while time.time() - t0 < timeout:
        d = get(i)
        if d and d["state_name"] in states: return d, time.time() - t0
        time.sleep(0.4)
    return get(i), time.time() - t0
def verify(path, size_mb):
    size = size_mb << 20
    if os.path.getsize(path) != size: return "size %d != %d" % (os.path.getsize(path), size)
    with open(path, "rb") as f:
        off = 0
        while off < size:
            n = min(1 << 20, size - off)
            if f.read(n) != O.content(off, n): return "content mismatch near byte %d" % off
            off += n
    return "OK"
results = []
def report(name, ok, detail=""):
    results.append(ok); print(("PASS " if ok else "FAIL ") + name + ("  -> " + detail if detail else ""), flush=True)

try:
    start_origin(); srv = start_server()
    print("per-connection cap %s MB/s, shared pipe %s MB/s" % (PER, TOTAL))

    # 1. info + legacy compat
    s, info = jreq("/v2/info"); report("info endpoint", s == 200 and info["api"] == 2, info["version"])
    s, t = req("/version"); report("legacy /version returns compat string", t == "1.05", t)

    # 2. baseline: single connection forced
    jreq("/v2/settings", {"auto_conns": False, "fixed_conns": 1, "max_conns_per_download": 1})
    s, r = add("single.bin", "/f?size=96", 96); i = r["id"]
    d, took1 = wait(i, ("done", "failed", "needs_link"), 120)
    report("single connection 96MB", d["state_name"] == "done" and verify(os.path.join(out, "single.bin"), 96) == "OK", "%.1fs (%.1f MB/s) mode=%s" % (took1, 96 / took1, d["mode"]))

    # 3. automatic mode
    jreq("/v2/settings", {"auto_conns": True, "max_conns_per_download": 8})
    s, r = add("auto.bin", "/f?size=192", 192); i = r["id"]
    peak = 0; t0 = time.time()
    while time.time() - t0 < 150:
        d = get(i); peak = max(peak, d["connections"])
        if d["state_name"] in ("done", "failed", "needs_link"): break
        time.sleep(0.4)
    took = time.time() - t0
    v = verify(os.path.join(out, "auto.bin"), 192)
    report("auto connections 192MB", d["state_name"] == "done" and v == "OK" and peak >= 4, "%.1fs (%.1f MB/s), peak %d connections, integrity %s; single was %.1f MB/s" % (took, 192 / took, peak, v, 96 / took1))

    # 4. pause / resume mid-download keeps data
    s, r = add("pause.bin", "/f?size=160", 160); i = r["id"]
    time.sleep(6); st, _ = jreq("/v2/pause", {"id": i}); d, _ = wait(i, ("paused",), 15)
    b1 = d["bytes"]; time.sleep(2); b2 = get(i)["bytes"]
    report("pause stops traffic", d["state_name"] == "paused" and b1 == b2 and 0 < b1 < (160 << 20), "bytes=%d" % b1)
    jreq("/v2/resume", {"id": i}); d, _ = wait(i, ("done", "failed"), 120)
    report("resume completes with correct data", d["state_name"] == "done" and verify(os.path.join(out, "pause.bin"), 160) == "OK")

    # 5. delete a running download without touching another one
    s, r1 = add("keep.bin", "/f?size=128", 128); s, r2 = add("kill.bin", "/f?size=128", 128)
    time.sleep(1.5)
    jreq("/v2/delete", {"id": r2["id"], "delete_files": True})
    time.sleep(1.5)
    ids = [x["id"] for x in dls()]
    report("delete one running download", r2["id"] not in ids and not os.path.exists(os.path.join(out, "kill.bin.tmp")) and not os.path.exists(os.path.join(out, "kill.bin")) )
    d, _ = wait(r1["id"], ("done", "failed"), 120)
    report("other download unaffected", d["state_name"] == "done" and verify(os.path.join(out, "keep.bin"), 128) == "OK")

    # 6. server without Range
    s, r = add("norange.bin", "/norange?size=40", 40); i = r["id"]
    d, took = wait(i, ("done", "failed", "needs_link"), 120)
    report("server ignoring Range (stream mode)", d["state_name"] == "done" and verify(os.path.join(out, "norange.bin"), 40) == "OK", "mode=" + d["mode"])

    # 7. html instead of file
    s, r = add("page.bin", "/html", 50); d, _ = wait(r["id"], ("needs_link", "failed", "done"), 20)
    report("web page instead of file is rejected", d["state_name"] == "needs_link" and not os.path.exists(os.path.join(out, "page.bin")), d["error"][:70])

    # 8. expired link, then re-send link with same destination
    s, r = add("exp.bin", "/expired?size=48", 48); d, _ = wait(r["id"], ("needs_link", "failed"), 20)
    ok1 = d["state_name"] == "needs_link"
    s, r2 = add("exp.bin", "/f?size=48", 48)
    d, _ = wait(r["id"], ("done", "failed", "needs_link"), 60)
    report("expired link then re-sent link continues", ok1 and r2.get("updated") and d["state_name"] == "done" and verify(os.path.join(out, "exp.bin"), 48) == "OK")

    # 9. host that refuses parallel requests -> falls back to 1 connection
    s, r = add("refuse.bin", "/refuse_parallel?size=80", 80); d, took = wait(r["id"], ("done", "failed", "needs_link"), 120)
    report("host refusing parallel connections", d["state_name"] == "done" and verify(os.path.join(out, "refuse.bin"), 80) == "OK", "%.1fs" % took)

    # 10. flaky connection (drops mid-chunk)
    s, r = add("flaky.bin", "/flaky?size=96", 96); d, took = wait(r["id"], ("done", "failed", "needs_link"), 180)
    report("flaky connection recovers", d["state_name"] == "done" and verify(os.path.join(out, "flaky.bin"), 96) == "OK", "%.1fs" % took)

    # 11. kill the server mid-download, restart, it resumes from disk
    s, r = add("crash.bin", "/f?size=160", 160); i = r["id"]; time.sleep(7)
    b_before = get(i)["bytes"]
    srv.kill(); srv.wait(); time.sleep(0.5)
    srv = start_server(); time.sleep(1.5)
    d = get(i); b_after_start = d["bytes"]
    d, _ = wait(i, ("done", "failed"), 150)
    report("hard kill then resume", d is not None and d["state_name"] == "done" and verify(os.path.join(out, "crash.bin"), 160) == "OK", "had %.0fMB before kill, restarted from ~%.0fMB" % (b_before / 1048576, b_after_start / 1048576))

    # 12. corrupt history file does not crash the server
    stop(srv); open(os.path.join(data, "bg_download_history.json"), "w").write("{ this is not json [[[")
    for f in ("bg_download_history.json.bak",):
        p = os.path.join(data, f)
        if os.path.exists(p): os.remove(p)
    srv = start_server(); s, _ = req("/get_download_state")
    report("corrupt history file survives startup", s == 200 and srv.poll() is None)

    # 13. legacy route + legacy state list shape
    s, r = add("legacy.bin", "/f?size=8", 8, legacy=True); time.sleep(3)
    s, t = req("/get_download_state"); L = json.loads(t)
    item = [x for x in L if x["path"].endswith("legacy.bin")]
    report("legacy /download_url + /get_download_state", s == 200 and item and set(item[0]) == {"path", "bytes_transfered", "file_size", "state", "timestamp"} and item[0]["state"] == 4, json.dumps(item[0]) if item else "missing")

    # 14. bad requests
    s, _ = req("/download_url", {"type": 7}, "POST"); report("invalid add is rejected with HTTP 400", s == 400, str(s))
    s, _ = req("/v2/pause", {"id": 999}, "POST"); report("unknown id gives 404", s == 404, str(s))

    stats = req("/stats".replace("/stats", ""))  # placeholder to keep flake8 quiet
finally:
    for p in procs:
        try: p.kill()
        except Exception: pass
    print("log tail:\n" + "")
    try:
        print(open(os.path.join(data, "dlserver.log")).read()[-2500:])
    except Exception: pass
    shutil.rmtree(work, ignore_errors=True)
print("\n%d/%d passed" % (sum(results), len(results)))
sys.exit(0 if all(results) else 1)
