#ifndef DL_API_H
#define DL_API_H
#include "http/httplib.h"

namespace DL
{
    // Registers the download routes on an httplib server:
    //   legacy (unchanged contract): POST /download_url, GET /get_download_state, GET /version
    //   new:  GET /v2/info, /v2/downloads, /v2/log; POST /v2/add, /v2/pause, /v2/resume, /v2/delete, /v2/settings
    void RegisterRoutes(httplib::Server &svr);
}
#endif
