#include <string>
#include <json-c/json.h>
#include "http/httplib.h"
#include "server/http_server.h"
#include "clients/remote_client.h"
#ifdef EZ_WITH_ARCHIVEORG
#include "clients/archiveorg.h"
#endif
#include "clients/baseclient.h"
#include "clients/ftpclient.h"
#include "clients/nfsclient.h"
#include "clients/smbclient.h"
#include "clients/sftpclient.h"
#include "clients/webdav.h"
#include "config.h"
#include "fs.h"
#include "util.h"
#include "dl/engine.h"
#include "dl/api.h"
#include "dl/minijson.h"

#define SUCCESS_MSG "{ \"result\": { \"success\": true, \"error\": null } }"
#define FAILURE_MSG "{ \"result\": { \"success\": false, \"error\": \"%s\" } }"
#define SUCCESS_MSG_LEN 48
#define MAX_PKG_REQUEST_SIZE 16777216ul
#define MIN(a,b) (((a)<(b))?(a):(b))

using namespace httplib;

Server *svr;
int http_server_port = 6701;

// One line per startup step in /data/ezremote_boot.log (same file as main.cpp writes), so a failed start can be diagnosed afterwards.
static void BootLog(const char *msg)
{
    FILE *f = fopen("/data/ezremote_boot.log", "a");
    if (f)
    {
        fprintf(f, "%s\n", msg);
        fclose(f);
    }
}
static uint64_t g_dl_offset;
static bool stop_server = false;
static bool in_rest_mode = false;

namespace HttpServer
{
    static int FtpCallback(int64_t xfered, void *arg)
    {
        return 1;
    }

    static int DownloadFtpCallback(int64_t xfered, void *arg)
    {
        *g_bytes_transfered = g_dl_offset + xfered;
        return 1;
    }

    std::string dump_headers(const Headers &headers)
    {
        std::string s;
        char buf[BUFSIZ];

        for (auto it = headers.begin(); it != headers.end(); ++it)
        {
            const auto &x = *it;
            snprintf(buf, sizeof(buf), "%s: %s\n", x.first.c_str(), x.second.c_str());
            s += buf;
        }

        return s;
    }

    std::string log(const Request &req, const Response &res)
    {
        std::string s;
        char buf[BUFSIZ];

        s += "================================\n";

        snprintf(buf, sizeof(buf), "%s %s %s", req.method.c_str(),
                 req.version.c_str(), req.path.c_str());
        s += buf;

        std::string query;
        for (auto it = req.params.begin(); it != req.params.end(); ++it)
        {
            const auto &x = *it;
            snprintf(buf, sizeof(buf), "%c%s=%s",
                     (it == req.params.begin()) ? '?' : '&', x.first.c_str(),
                     x.second.c_str());
            query += buf;
        }
        snprintf(buf, sizeof(buf), "%s\n", query.c_str());
        s += buf;

        s += dump_headers(req.headers);

        s += "--------------------------------\n";

        snprintf(buf, sizeof(buf), "%d %s\n", res.status, res.version.c_str());
        s += buf;
        s += dump_headers(res.headers);
        s += "\n";

        if (!res.body.empty())
        {
            s += res.body;
        }

        s += "\n";

        return s;
    }

    static std::string JsonEscape(const std::string &in)
    {
        std::string out;
        for (unsigned char c : in)
        {
            switch (c)
            {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20)
                {
                    char b[8];
                    snprintf(b, sizeof(b), "\\u%04x", c);
                    out += b;
                }
                else
                    out += (char)c;
            }
        }
        return out;
    }

    // msg may contain text from the request (a hash, a remote error): escape it and avoid a stack buffer sized by it
    void failed(Response &res, int status, const std::string &msg)
    {
        res.status = status;
        std::string body = "{ \"result\": { \"success\": false, \"error\": \"" + JsonEscape(msg) + "\" } }";
        res.set_content(body, "application/json");
        return;
    }

    void bad_request(Response &res, const std::string &msg)
    {
        failed(res, 200, msg);
        return;
    }

    void success(Response &res)
    {
        res.status = 200;
        res.set_content(SUCCESS_MSG, SUCCESS_MSG_LEN, "application/json");
        return;
    }

    static RemoteClient *GetRemoteClient(HostInfo *host_info)
    {
        RemoteClient *tmp_client = nullptr;

        if (host_info->client != nullptr)
        {
            return host_info->client;
        }
        else if (host_info->type == CLIENT_TYPE_HTTP_SERVER)
        {
#ifdef EZ_WITH_ARCHIVEORG
            if (host_info->http_server_type.compare(HTTP_SERVER_ARCHIVEORG) == 0)
            {
                tmp_client = new ArchiveOrgClient();
                host_info->client = tmp_client;
            }
            else
#endif
            {
                // without the archive.org client (needs lexbor) archive.org links use the plain HTTP client
                tmp_client = new BaseClient();
            }
        }
        else if (host_info->type == CLIENT_TYPE_WEBDAV)
        {
            tmp_client = new WebDAVClient();
        }
        else if (host_info->type == CLIENT_TYPE_FILEHOST)
        {
            tmp_client = new BaseClient();
        }
        else if (host_info->type == CLIENT_TYPE_SMB)
        {
            tmp_client = new SmbClient();
        }
        else if (host_info->type == CLIENT_TYPE_SFTP)
        {
            tmp_client = new SFTPClient();
        }
        else if (host_info->type == CLIENT_TYPE_NFS)
        {
            tmp_client = new NfsClient();
        }
        else if (host_info->type == CLIENT_TYPE_FTP)
        {
            tmp_client = new FtpClient();
            FtpClient *ftp_client = (FtpClient*) tmp_client;
            ftp_client->SetCallbackXferFunction(FtpCallback);
        }

        if (tmp_client != nullptr)
            tmp_client->Connect(host_info->url, host_info->username, host_info->password);

        return tmp_client;
    }

    static void DeleteRemoteClient(RemoteClient *tmp_client)
    {
#ifdef EZ_WITH_ARCHIVEORG
        if (!dynamic_cast<ArchiveOrgClient*>(tmp_client))
#endif
        {
            tmp_client->Quit();
            delete tmp_client;
        }
    }

    // Downloads that are not plain file-host downloads (FTP, SMB, NFS, SFTP, WebDAV, HTTP servers) still use the
    // original RemoteClient classes. The download engine runs these one at a time (they share global pointers).
    static int LegacyGet(DL::LegacyJob &job)
    {
        HostInfo hi;
        hi.type = job.host.type;
        hi.url = job.host.url;
        hi.http_server_type = job.host.http_server_type;
        hi.username = job.host.username;
        hi.password = job.host.password;
        hi.client = nullptr;

        RemoteClient *c = GetRemoteClient(&hi);
        if (c == nullptr)
        {
            job.error = "Cannot create a client for this download type";
            return 0;
        }
        g_bytes_transfered = job.progress;
        g_cancel_flag = job.cancel;
        if (hi.type == CLIENT_TYPE_FTP)
        {
            FtpClient *ftpclient = (FtpClient *)c;
            g_dl_offset = job.offset;
            ftpclient->SetCallbackBytes(1);
            ftpclient->SetCallbackXferFunction(DownloadFtpCallback);
        }

        int ret = (job.offset > 0) ? c->Get(job.tmp_path, job.src_path, job.offset) : c->Get(job.tmp_path, job.src_path);
        if (!ret)
        {
            const char *r = c->LastResponse();
            job.error = (r != nullptr && r[0] != 0) ? r : "Transfer failed";
        }
        g_cancel_flag = nullptr;
        DeleteRemoteClient(c);
        return ret;
    }

    void *ServerThread(void *argp)
    {
        svr->Post("/store_bg_install_data", [&](const Request &req, Response &res)
        {
            const char *hash_param;
            const char *path_param;
            const char *url_param;
            const char *username_param;
            const char *password_param;
            const char *http_server_type_param;
            uint64_t file_size_param;
            int type_param;

            json_object *jobj = json_tokener_parse(req.body.c_str());
            if (jobj != nullptr)
            {
                hash_param = json_object_get_string(json_object_object_get(jobj, "hash"));
                url_param = json_object_get_string(json_object_object_get(jobj, "url"));
                path_param = json_object_get_string(json_object_object_get(jobj, "path"));
                username_param  = json_object_get_string(json_object_object_get(jobj, "username"));
                password_param = json_object_get_string(json_object_object_get(jobj, "password"));
                http_server_type_param = json_object_get_string(json_object_object_get(jobj, "http_server_type"));
                type_param = json_object_get_int(json_object_object_get(jobj, "type"));
                file_size_param = json_object_get_uint64(json_object_object_get(jobj, "file_size"));

                if (url_param == nullptr || hash_param == nullptr)
                {
                    bad_request(res, "Required url_param or hash parameter missing");
                    return;
                }

                PackageInstallData pkg_data;
                pkg_data.host_info.url = url_param;
                if (username_param != nullptr)
                    pkg_data.host_info.username = username_param;
                if (password_param != nullptr)
                    pkg_data.host_info.password = password_param;
                if (path_param != nullptr)
                    pkg_data.path = path_param;
                if (http_server_type_param != nullptr)
                    pkg_data.host_info.http_server_type = http_server_type_param;
                pkg_data.timestamp = Util::GetTick();
                pkg_data.host_info.type = type_param;
                pkg_data.size = file_size_param;
                pkg_data.host_info.client = nullptr;

                CONFIG::AddPackageInstallHostData(hash_param, pkg_data);
                CONFIG::SavePackageInstallHostData();
                json_object_put(jobj);
                success(res);
            }
            else
            {
                bad_request(res, "Invalid JSON");
            }
        });

        svr->Get("/bg_install/(.*)", [&](const Request &req, Response &res)
        {
            std::string hash = req.matches[1];
            PackageInstallData* pkg_host_data = CONFIG::GetPackageInstallHostData(hash);
            RemoteClient *tmp_client;

            if (pkg_host_data == nullptr)
            {
                failed(res, 500, "Cannot resume background install of " + hash + ". Host data not found.");
                return;
            }

            tmp_client = GetRemoteClient(&(pkg_host_data->host_info));
            if (tmp_client == nullptr)
            {
                res.status = 500;
                return;
            }

            std::string path = pkg_host_data->path;

            if (req.ranges.empty())
            {
                res.status = 200;

                res.set_content_provider(
                    pkg_host_data->size, "application/octet-stream",
                    [tmp_client, path](size_t offset, size_t length, DataSink &sink) {
                        // On pkg initial request, the PS4 doesn't really need to get the full content of the pkg,
                        // probably just to get the content length or check if pkg exists so just return the first 128kb
                        int ret = tmp_client->GetRange(path, sink, (1024*128), offset);
                        return (ret == 1);
                    },
                    [tmp_client, path](bool success) {
                        DeleteRemoteClient(tmp_client);
                    });
            }
            else
            {
                res.status = 206;
                res.set_content_provider(
                    pkg_host_data->size, "application/octet-stream",
                    [tmp_client, path](size_t offset, size_t length, DataSink &sink) {
                        int ret;
                        // On some pkg request, it range it from xxx-pkg_size which can be in several GBS.
                        // Only return the MAX_PKG_REQUEST_SIZE of 16MB
                        size_t read_length = MIN(length, MAX_PKG_REQUEST_SIZE);
                        ret = tmp_client->GetRange(path, sink, read_length, offset);
                        return (ret==1);
                    },
                    [tmp_client, path](bool success) {
                        DeleteRemoteClient(tmp_client);
                    });
            }
        });

        // download routes: /download_url, /get_download_state, /version (legacy contract) and /v2/*
        DL::RegisterRoutes(*svr);

        svr->Get("/stop", [&](const Request &req, Response &res)
        {
            // without a token anybody on the network could stop the server; with one, X-Token is required
            if (!DL::Authorized(req, res))
                return;
            stop_server = true;
            svr->stop();
        });

        svr->set_error_handler([](const Request & /*req*/, Response &res)
        {
            const char *fmt = "<p>Error Status: <span style='color:red;'>%d</span></p>";
            char buf[BUFSIZ];
            snprintf(buf, sizeof(buf), fmt, res.status);
            res.set_content(buf, "text/html");
        });

        /*
        svr->set_logger([](const Request &req, const Response &res)
        {
            dbglogger_log("%s", log(req, res).c_str());
        });
        */
       
        svr->set_payload_max_length(1024 * 1024 * 12);
        svr->set_tcp_nodelay(true);
        // The original code served the whole PS4 file system ("/") over HTTP to the network without authentication.

        // bind first so that success and failure are known (and logged); a busy port is retried by Start()
        if (!svr->bind_to_port("0.0.0.0", http_server_port))
        {
            BootLog("5 bind to port 6701 FAILED (port busy?), will retry");
            return NULL;
        }
        BootLog("5 listening on port 6701");
        Util::Notify("ezRemote Server (custom %s) is running on port %d", DL::kVersion, http_server_port);
        svr->listen_after_bind();

        return NULL;
    }

    void PauseDownloadThread()
    {
        in_rest_mode = true;
        DL::SetRestMode(true);
    }

    void ResumeDownloadThread()
    {
        in_rest_mode = false;
        DL::SetRestMode(false);
    }

    void Start()
    {
        if (svr == nullptr)
            svr = new Server();
        if (!svr->is_valid())
        {
            return;
        }
        
        while (!stop_server)
        {
            if (!in_rest_mode)
            {
                ServerThread(nullptr);
            }

            if (!stop_server && !in_rest_mode)
            {
                // the port may still be held by the original server: ask it to stop again (every round), then retry the bind
                {
                    httplib::Client c = httplib::Client("http://127.0.0.1:6701");
                    c.set_connection_timeout(1);
                    c.set_read_timeout(2);
                    c.set_default_headers({{"X-Token", DL::StoredToken(DATA_PATH)}});
                    c.Get("/stop");
                }
                sleep(3);
                delete svr;
                svr = new Server();
            }
        }
    }

    void Stop()
    {
        stop_server = true;
        if (svr != nullptr)
            svr->stop();
    }

    void StartDownloadThread()
    {
        DL::Hooks hooks;
        hooks.notify = [](const std::string &m) { Util::Notify("%s", m.c_str()); };
        hooks.legacy_get = LegacyGet;
        hooks.encrypt = [](const std::string &p) { std::string out; return CONFIG::Encrypt(p, out) ? out : p; };
        hooks.decrypt = [](const std::string &p) { std::string out; return CONFIG::Decrypt(p, out) ? out : p; };
        hooks.filehost_type = CLIENT_TYPE_FILEHOST;
        DL::Init(DATA_PATH, hooks);
        DL::Start();
    }

    void StopDownloadThread()
    {
        DL::Shutdown();
    }

    // 0: nothing on the port, 1: this server (same version), 2: another ezRemote Server (original or other version)
    int RunningKind()
    {
        httplib::Client client = httplib::Client("http://127.0.0.1:6701");
        client.set_connection_timeout(2);
        client.set_read_timeout(3);
        // when a token is configured, /v2/info needs it (read from the settings file: the engine is not started yet)
        client.set_default_headers({{"X-Token", DL::StoredToken(DATA_PATH)}});
        if (auto res = client.Get("/v2/info"))
        {
            if (res->status == 200)
            {
                mj::Json j;
                if (mj::Json::parse(res->body, j) && j.getStr("version") == DL::kVersion)
                    return 1;
                return 2;
            }
        }
        if (auto res = client.Get("/version"))
        {
            return 2;
        }
        return 0;
    }

    bool IsStarted()
    {
        return RunningKind() != 0;
    }

    // Stops a different ezRemote Server (the original, or an older build of this one) so this one can take over.
    bool ReplaceRunning()
    {
        // three rounds: ask it to stop, then wait up to ~10 s for the port to become free
        for (int round = 1; round <= 3; round++)
        {
            httplib::Client client = httplib::Client("http://127.0.0.1:6701");
            client.set_connection_timeout(2);
            client.set_read_timeout(3);
            client.set_default_headers({{"X-Token", DL::StoredToken(DATA_PATH)}});
            client.Get("/stop");
            for (int i = 0; i < 40; i++)
            {
                usleep(250 * 1000);
                if (RunningKind() == 0)
                {
                    BootLog("3b the previous server stopped");
                    return true;
                }
            }
            BootLog("3b the previous server did not stop yet, asking again");
        }
        return false;
    }
}
