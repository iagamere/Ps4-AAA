// Diagnostic payload: proves step by step what works when a payload built with this toolchain is sent to GoldHEN.
// Every step shows a notification on the PS4 and is appended to /data/ezremote-client/hello.txt.
// After the last step it serves "hello" on http://<PS4 IP>:6702 (open it from the phone browser).
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <chrono>

#if defined(__has_include)
#if __has_include(<orbis/libkernel.h>)
#include <orbis/libkernel.h>
#define HAVE_ORBIS_LIBKERNEL 1
#endif
#endif
#ifndef HAVE_ORBIS_LIBKERNEL
extern "C" {
int sceKernelSendNotificationRequest(int, void *, size_t, int);
}
#endif

extern "C"
{
    int sceNetInit(void);
    int sceNetPoolCreate(const char *name, int size, int flags);
}

typedef struct notify_request
{
    char useless1[45];
    char message[3075];
} notify_request_t;

static void Say(const char *fmt, ...)
{
    char msg[300];
    va_list args;
    va_start(args, fmt);
    vsnprintf(msg, sizeof(msg), fmt, args);
    va_end(args);

    notify_request_t req;
    memset(&req, 0, sizeof(req));
    snprintf(req.message, sizeof(req.message), "HELLO: %s", msg);
#ifdef HAVE_ORBIS_LIBKERNEL
    sceKernelSendNotificationRequest(0, reinterpret_cast<OrbisNotificationRequest *>(&req), sizeof(req), 0);
#else
    sceKernelSendNotificationRequest(0, &req, sizeof(req), 0);
#endif
    mkdir("/data/ezremote-client", 0777);
    FILE *f = fopen("/data/ezremote-client/hello.txt", "a");
    if (f)
    {
        fprintf(f, "%s\n", msg);
        fclose(f);
    }
    sleep(1); // keep notifications readable
}

static void *ThreadFn(void *arg)
{
    *(int *)arg = 42;
    return nullptr;
}

int main(int argc, char *argv[])
{
    Say("1/7 main() reached");

    int r = sceNetInit();
    Say("2/7 sceNetInit = %d", r);
    int pool = sceNetPoolCreate("hello", 1 * 1024 * 1024, 0);
    Say("3/7 sceNetPoolCreate = %d", pool);

    // threads with an explicit 4 MB stack (the download engine does this)
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 4u * 1024 * 1024);
    pthread_t th;
    int value = 0;
    int pr = pthread_create(&th, &attr, ThreadFn, &value);
    if (pr == 0)
        pthread_join(th, nullptr);
    Say("4/7 pthread_create = %d, value = %d", pr, value);

    // file calls the engine uses
    int fd = open("/data/ezremote-client/hello.bin", O_RDWR | O_CREAT, 0666);
    int w = (fd >= 0) ? (int)pwrite(fd, "abcdef", 6, 10) : -1;
    int fs = (fd >= 0) ? fsync(fd) : -1;
    int ft = (fd >= 0) ? ftruncate(fd, 8) : -1;
    if (fd >= 0)
        close(fd);
    int rn = rename("/data/ezremote-client/hello.bin", "/data/ezremote-client/hello2.bin");
    Say("5/7 open=%d pwrite=%d fsync=%d ftruncate=%d rename=%d", fd, w, fs, ft, rn);
    unlink("/data/ezremote-client/hello2.bin");

    auto t0 = std::chrono::steady_clock::now();
    usleep(100 * 1000);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
    Say("6/7 steady_clock + usleep: %lld ms", (long long)ms);

    signal(SIGPIPE, SIG_IGN);
    int s = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons(6702);
    int b = bind(s, (sockaddr *)&addr, sizeof(addr));
    int l = listen(s, 8);
    Say("7/7 socket=%d bind=%d listen=%d (errno %d). Open http://PS4-IP:6702", s, b, l, errno);

    while (true)
    {
        int c = accept(s, nullptr, nullptr);
        if (c < 0)
            continue;
        char buf[512];
        recv(c, buf, sizeof(buf), 0);
        const char *body = "hello from the test payload";
        char resp[256];
        int n = snprintf(resp, sizeof(resp), "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s", (int)strlen(body), body);
        send(c, resp, n, 0);
        close(c);
    }
    return 0;
}
