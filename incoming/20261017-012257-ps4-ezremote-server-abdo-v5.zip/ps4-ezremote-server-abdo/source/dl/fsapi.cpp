// File API for the companion app: lets it browse / read / delete / rename / create folders through the download
// server (port 6701), which keeps running while a game is open, instead of through ezRemote Client's web server
// (port 8080), which the PS4 suspends together with the client.
// Disabled unless the setting fs_roots lists at least one folder; every path must resolve (symlinks included)
// to a place inside one of those folders. Uses the same X-Token and cross-site guards as the other /v2 routes.
#include "dl/api.h"
#include "dl/engine.h"

#include <algorithm>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

namespace DL
{
    using namespace httplib;

    static const size_t kMaxRead = 8u * 1024 * 1024;
    static const size_t kMaxEntries = 5000;

    static void Reply(Response &res, int status, const mj::Json &j)
    {
        res.status = status;
        res.set_content(j.dump(), "application/json");
    }
    static void Fail(Response &res, int status, const std::string &msg)
    {
        mj::Json j = mj::Json::object();
        j.set("ok", mj::Json::boolean(false));
        j.set("error", mj::Json::str(msg));
        Reply(res, status, j);
    }

    static bool LexicallyBad(const std::string &p)
    {
        if (p.empty() || p[0] != '/' || p.size() > 4000) return true;
        if (p.find('\0') != std::string::npos) return true;
        size_t pos = 0;
        while (pos < p.size())
        {
            size_t e = p.find('/', pos);
            if (e == std::string::npos) e = p.size();
            if (p.compare(pos, e - pos, "..") == 0) return true;
            pos = e + 1;
        }
        return false;
    }

    static std::string Real(const std::string &p)
    {
        char buf[PATH_MAX];
        if (!realpath(p.c_str(), buf)) return "";
        return buf;
    }

    static bool Inside(const std::string &path, const std::string &root)
    {
        return path == root || (path.size() > root.size() && path.compare(0, root.size(), root) == 0 && path[root.size()] == '/');
    }

    // Resolves a requested path to a real path inside fs_roots. mustExist=false: the last component may be missing
    // (its parent must exist and be inside). err gets the HTTP status via code.
    static bool Resolve(const std::string &req, bool mustExist, std::string &out, int &code, std::string &err, bool deepMissing = false)
    {
        Settings s = GetSettings();
        if (s.fs_roots.empty())
        {
            code = 403;
            err = "File API is disabled (fs_roots is empty)";
            return false;
        }
        std::string p = req;
        while (p.size() > 1 && p.back() == '/') p.pop_back();
        if (LexicallyBad(p))
        {
            code = 400;
            err = "Invalid path";
            return false;
        }
        std::string real = Real(p);
        if (real.empty())
        {
            if (mustExist || errno != ENOENT)
            {
                code = (errno == ENOENT) ? 404 : 400;
                err = (errno == ENOENT) ? "No such file or folder" : "Cannot resolve path";
                return false;
            }
            // walk up to the nearest existing ancestor (only one level when deepMissing is false)
            std::string rest, anc = p;
            int levels = 0;
            std::string rp;
            while (true)
            {
                size_t sl = anc.rfind('/');
                if (sl == std::string::npos || anc.size() <= 1) break;
                rest = anc.substr(sl) + rest;
                anc = sl == 0 ? "/" : anc.substr(0, sl);
                levels++;
                if (!deepMissing && levels > 1) break;
                rp = Real(anc);
                if (!rp.empty()) break;
            }
            if (rp.empty() || rest.size() < 2)
            {
                code = 404;
                err = "Parent folder does not exist";
                return false;
            }
            real = (rp == "/" ? "" : rp) + rest;
        }
        for (auto &r : s.fs_roots)
        {
            std::string rr = Real(r);
            if (!rr.empty() && Inside(real, rr))
            {
                out = real;
                return true;
            }
        }
        code = 403;
        err = "Path is outside the allowed folders (fs_roots)";
        return false;
    }

    static bool IsRoot(const std::string &real)
    {
        Settings s = GetSettings();
        for (auto &r : s.fs_roots)
            if (Real(r) == real) return true;
        return false;
    }

    static mj::Json EntryJson(const std::string &name, const struct stat &st)
    {
        mj::Json e = mj::Json::object();
        e.set("name", mj::Json::str(name));
        e.set("dir", mj::Json::boolean(S_ISDIR(st.st_mode)));
        e.set("size", mj::Json::num(S_ISDIR(st.st_mode) ? 0 : (int64_t)st.st_size));
        e.set("mtime", mj::Json::num((int64_t)st.st_mtime));
        // wall-clock text like ezRemote Client's own listing ("YYYY-MM-DD HH:MM:SS", console local time)
        struct tm tmv;
        time_t mt = st.st_mtime;
        char buf[32] = "";
        if (localtime_r(&mt, &tmv)) strftime(buf, sizeof buf, "%Y-%m-%d %H:%M:%S", &tmv);
        e.set("date", mj::Json::str(buf));
        return e;
    }

    static bool RemoveTree(const std::string &p, int depth, std::string &err)
    {
        struct stat st;
        if (lstat(p.c_str(), &st) != 0)
        {
            err = "Cannot stat " + p;
            return false;
        }
        if (S_ISDIR(st.st_mode))
        {
            if (depth > 40)
            {
                err = "Folder tree too deep";
                return false;
            }
            DIR *d = opendir(p.c_str());
            if (!d)
            {
                err = "Cannot open " + p;
                return false;
            }
            std::vector<std::string> names;
            while (struct dirent *de = readdir(d))
            {
                std::string n = de->d_name;
                if (n != "." && n != "..") names.push_back(n);
            }
            closedir(d);
            for (auto &n : names)
                if (!RemoveTree(p + "/" + n, depth + 1, err)) return false;
            if (rmdir(p.c_str()) != 0)
            {
                err = "Cannot remove folder " + p;
                return false;
            }
            return true;
        }
        if (unlink(p.c_str()) != 0)
        {
            err = "Cannot delete " + p;
            return false;
        }
        return true;
    }

    static bool MkDirs(const std::string &p, std::string &err)
    {
        size_t pos = 1;
        while (pos <= p.size())
        {
            size_t e = p.find('/', pos);
            if (e == std::string::npos) e = p.size();
            std::string part = p.substr(0, e);
            struct stat st;
            if (stat(part.c_str(), &st) != 0)
            {
                if (mkdir(part.c_str(), 0777) != 0 && errno != EEXIST)
                {
                    err = "Cannot create " + part;
                    return false;
                }
            }
            else if (!S_ISDIR(st.st_mode))
            {
                err = part + " is not a folder";
                return false;
            }
            pos = e + 1;
        }
        return true;
    }

    static std::string PathParam(const Request &req, mj::Json &body, const char *key)
    {
        if (req.has_param(key)) return req.get_param_value(key);
        if (body.t == mj::Json::Obj) return body.getStr(key);
        return "";
    }

    void RegisterFsRoutes(Server &svr)
    {
        svr.Get("/v2/fs/roots", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            Settings s = GetSettings();
            mj::Json arr = mj::Json::array();
            for (auto &r : s.fs_roots)
            {
                std::string rr = Real(r);
                if (!rr.empty()) arr.push(mj::Json::str(r));
            }
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            j.set("enabled", mj::Json::boolean(!s.fs_roots.empty()));
            j.set("roots", arr);
            Reply(res, 200, j);
        });

        svr.Get("/v2/fs/list", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            std::string real, err;
            int code = 400;
            if (!Resolve(req.get_param_value("path"), true, real, code, err)) return Fail(res, code, err);
            struct stat st;
            if (stat(real.c_str(), &st) != 0 || !S_ISDIR(st.st_mode)) return Fail(res, 400, "Not a folder");
            DIR *d = opendir(real.c_str());
            if (!d) return Fail(res, 403, "Cannot open folder");
            mj::Json arr = mj::Json::array();
            bool truncated = false;
            while (struct dirent *de = readdir(d))
            {
                std::string n = de->d_name;
                if (n == "." || n == "..") continue;
                if (arr.a.size() >= kMaxEntries)
                {
                    truncated = true;
                    break;
                }
                struct stat es;
                if (stat((real + "/" + n).c_str(), &es) != 0 && lstat((real + "/" + n).c_str(), &es) != 0) continue;
                arr.push(EntryJson(n, es));
            }
            closedir(d);
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            j.set("path", mj::Json::str(real));
            j.set("entries", arr);
            j.set("truncated", mj::Json::boolean(truncated));
            Reply(res, 200, j);
        });

        // exists / size without an error status for "missing", so the app can ask cheaply
        svr.Get("/v2/fs/stat", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            std::string real, err;
            int code = 400;
            if (!Resolve(req.get_param_value("path"), false, real, code, err)) return Fail(res, code, err);
            struct stat st;
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            if (stat(real.c_str(), &st) != 0)
            {
                j.set("exists", mj::Json::boolean(false));
                return Reply(res, 200, j);
            }
            j.set("exists", mj::Json::boolean(true));
            j.set("dir", mj::Json::boolean(S_ISDIR(st.st_mode)));
            j.set("size", mj::Json::num(S_ISDIR(st.st_mode) ? 0 : (int64_t)st.st_size));
            j.set("mtime", mj::Json::num((int64_t)st.st_mtime));
            Reply(res, 200, j);
        });

        // raw bytes: ?path=&offset=&length= (length capped at 8 MiB). Header X-File-Size carries the total size.
        svr.Get("/v2/fs/read", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            std::string real, err;
            int code = 400;
            if (!Resolve(req.get_param_value("path"), true, real, code, err)) return Fail(res, code, err);
            struct stat st;
            if (stat(real.c_str(), &st) != 0 || !S_ISREG(st.st_mode)) return Fail(res, 400, "Not a regular file");
            int64_t off = req.has_param("offset") ? strtoll(req.get_param_value("offset").c_str(), nullptr, 10) : 0;
            int64_t len = req.has_param("length") ? strtoll(req.get_param_value("length").c_str(), nullptr, 10) : (int64_t)kMaxRead;
            if (off < 0 || len < 0) return Fail(res, 400, "Invalid range");
            if (len > (int64_t)kMaxRead) len = kMaxRead;
            if (off > (int64_t)st.st_size) off = st.st_size;
            if (off + len > (int64_t)st.st_size) len = st.st_size - off;
            std::string data;
            data.resize((size_t)len);
            if (len > 0)
            {
                int fd = open(real.c_str(), O_RDONLY);
                if (fd < 0) return Fail(res, 403, "Cannot open file");
                size_t got = 0;
                while (got < (size_t)len)
                {
                    ssize_t n = pread(fd, &data[got], (size_t)len - got, (off_t)(off + got));
                    if (n <= 0) break;
                    got += (size_t)n;
                }
                close(fd);
                data.resize(got);
            }
            res.status = 200;
            res.set_header("X-File-Size", std::to_string((long long)st.st_size));
            res.set_content(data, "application/octet-stream");
        });

        svr.Post("/v2/fs/delete", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            if (!req.body.empty()) mj::Json::parse(req.body, body);
            std::string real, err;
            int code = 400;
            if (!Resolve(PathParam(req, body, "path"), true, real, code, err)) return Fail(res, code, err);
            if (IsRoot(real)) return Fail(res, 400, "Refusing to delete an allowed root folder");
            if (!RemoveTree(real, 0, err)) return Fail(res, 500, err);
            Log("fs delete: %s", real.c_str());
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            Reply(res, 200, j);
        });

        svr.Post("/v2/fs/rename", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            if (!req.body.empty()) mj::Json::parse(req.body, body);
            std::string from, to, err;
            int code = 400;
            if (!Resolve(PathParam(req, body, "from"), true, from, code, err)) return Fail(res, code, err);
            if (!Resolve(PathParam(req, body, "to"), false, to, code, err)) return Fail(res, code, err);
            if (IsRoot(from)) return Fail(res, 400, "Refusing to rename an allowed root folder");
            struct stat st;
            if (lstat(to.c_str(), &st) == 0) return Fail(res, 409, "Destination already exists");
            if (rename(from.c_str(), to.c_str()) != 0) return Fail(res, 500, std::string("Rename failed: ") + strerror(errno));
            Log("fs rename: %s -> %s", from.c_str(), to.c_str());
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            Reply(res, 200, j);
        });

        svr.Post("/v2/fs/mkdir", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            if (!req.body.empty()) mj::Json::parse(req.body, body);
            std::string real, err;
            int code = 400;
            if (!Resolve(PathParam(req, body, "path"), false, real, code, err, true)) return Fail(res, code, err);
            if (!MkDirs(real, err)) return Fail(res, 500, err);
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            Reply(res, 200, j);
        });
    }
}
