#include "dl/api.h"
#include "dl/engine.h"

#include <algorithm>

namespace DL
{
    using namespace httplib;

    static void Reply(Response &res, int status, const mj::Json &j)
    {
        res.status = status;
        res.set_content(j.dump(), "application/json");
    }
    static void Fail(Response &res, int status, const std::string &msg)
    {
        mj::Json j = mj::Json::object();
        j.set("ok", mj::Json::boolean(false));
        j.set("error", mj::Json::str(msg));
        Reply(res, status, j);
    }
    static void Ok(Response &res)
    {
        mj::Json j = mj::Json::object();
        j.set("ok", mj::Json::boolean(true));
        Reply(res, 200, j);
    }
    // compares without leaking where the first difference is
    static bool SameToken(const std::string &a, const std::string &b)
    {
        size_t n = std::max(a.size(), b.size());
        unsigned char diff = (a.size() != b.size()) ? 1 : 0;
        for (size_t i = 0; i < n; i++)
            diff |= (unsigned char)((i < a.size() ? a[i] : 0) ^ (i < b.size() ? b[i] : 0));
        return diff == 0;
    }
    bool Authorized(const Request &req, Response &res)
    {
        Settings s = GetSettings();
        if (s.token.empty()) return true;
        if (SameToken(req.get_header_value("X-Token"), s.token)) return true;
        Fail(res, 401, "Missing or wrong X-Token");
        return false;
    }

    // A web page in a browser on the same network could otherwise make the console download files (CSRF) or stop the
    // server. Browsers always send Origin and/or Sec-Fetch-Site on such requests; native clients (ezRemote Client,
    // curl, our app) send neither, so they are not affected.
    static bool CrossSiteBrowserRequest(const Request &req)
    {
        std::string sfs = req.get_header_value("Sec-Fetch-Site");
        if (!sfs.empty() && sfs != "same-origin" && sfs != "none") return true;
        std::string origin = req.get_header_value("Origin");
        if (!origin.empty())
        {
            size_t p = origin.find("://");
            std::string oh = (p == std::string::npos) ? origin : origin.substr(p + 3);
            if (oh != req.get_header_value("Host")) return true;
        }
        return false;
    }

    // body of /download_url and /v2/add (same fields as the original ezRemote Server)
    static void HandleAdd(const Request &req, Response &res, bool v2)
    {
        mj::Json j;
        if (!mj::Json::parse(req.body, j) || j.t != mj::Json::Obj)
        {
            if (v2) Fail(res, 400, "Invalid JSON");
            else res.status = 400;
            return;
        }
        Host h;
        h.type = (int)j.getInt("type");
        h.url = j.getStr("url");
        h.username = j.getStr("username");
        h.password = j.getStr("password");
        h.http_server_type = j.getStr("http_server_type");
        int prio = v2 ? (int)j.getInt("priority") : 0;
        bool top = v2 && j.getBool("top");
        AddResult r = Add(h, j.getStr("src_path"), j.getStr("dest_path"), (uint64_t)j.getInt("size"), (uint64_t)j.getInt("id"), prio, top);
        if (!r.ok)
        {
            Log("add rejected: %s", r.error.c_str());
            if (v2) Fail(res, 400, r.error);
            else
            {
                // the unmodified client only looks at the HTTP status and reports "Failed to download" for non-2xx
                res.status = 400;
                res.set_content(std::string("{ \"result\": { \"success\": false, \"error\": \"") + r.error + "\" } }", "application/json");
            }
            return;
        }
        mj::Json out = mj::Json::object();
        out.set("ok", mj::Json::boolean(true));
        out.set("id", mj::Json::num(r.uid));
        out.set("updated", mj::Json::boolean(r.updated));
        if (v2) Reply(res, 200, out);
        else
        {
            res.status = 200;
            res.set_content("{ \"result\": { \"success\": true, \"error\": null } }", "application/json");
        }
    }

    // id from JSON body or query string; all=true applies to every download
    static bool ReadId(const Request &req, mj::Json &body, uint32_t &id, bool &all)
    {
        all = false;
        id = 0;
        if (!req.body.empty()) mj::Json::parse(req.body, body);
        if (body.t == mj::Json::Obj)
        {
            all = body.getBool("all");
            id = (uint32_t)body.getInt("id");
        }
        if (req.has_param("id")) id = (uint32_t)strtoul(req.get_param_value("id").c_str(), nullptr, 10);
        if (req.has_param("all")) all = req.get_param_value("all") == "true" || req.get_param_value("all") == "1";
        return all || id != 0;
    }

    void RegisterRoutes(Server &svr)
    {
        svr.set_pre_routing_handler([](const Request &req, Response &res) {
            if (CrossSiteBrowserRequest(req))
            {
                res.status = 403;
                res.set_content("Cross-site request blocked", "text/plain");
                return Server::HandlerResponse::Handled;
            }
            return Server::HandlerResponse::Unhandled;
        });

        // ---------------- legacy routes (same contract as the original server) ----------------
        svr.Post("/download_url", [](const Request &req, Response &res) { HandleAdd(req, res, false); });

        svr.Get("/get_download_state", [](const Request &, Response &res) {
            res.status = 200;
            res.set_content(ListJson(true).dump(), "application/json");
        });

        // The unmodified ezRemote Client compares this text with the server version it was built for and shows a
        // warning dialog when it differs. Report the compatible number here; the real one is in /v2/info.
        svr.Get("/version", [](const Request &, Response &res) {
            res.status = 200;
            res.set_content(kCompatVersion, "text/html");
        });

        // ---------------- v2 ----------------
        svr.Get("/v2/info", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            Reply(res, 200, InfoJson());
        });

        svr.Get("/v2/downloads", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            j.set("downloads", ListJson(false));
            Reply(res, 200, j);
        });

        svr.Get("/v2/log", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            int n = 100;
            if (req.has_param("lines")) n = atoi(req.get_param_value("lines").c_str());
            res.status = 200;
            res.set_content(LogTail(n), "text/plain; charset=utf-8");
        });

        svr.Post("/v2/add", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            HandleAdd(req, res, true);
        });

        svr.Post("/v2/pause", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            uint32_t id;
            bool all;
            if (!ReadId(req, body, id, all)) return Fail(res, 400, "id is required");
            if (all)
            {
                mj::Json j = mj::Json::object();
                j.set("ok", mj::Json::boolean(true));
                j.set("count", mj::Json::num(PauseAll()));
                return Reply(res, 200, j);
            }
            std::string err;
            if (!Pause(id, err)) return Fail(res, 404, err);
            Ok(res);
        });

        svr.Post("/v2/resume", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            uint32_t id;
            bool all;
            if (!ReadId(req, body, id, all)) return Fail(res, 400, "id is required");
            if (all)
            {
                mj::Json j = mj::Json::object();
                j.set("ok", mj::Json::boolean(true));
                j.set("count", mj::Json::num(ResumeAll()));
                return Reply(res, 200, j);
            }
            std::string err;
            if (!Resume(id, err)) return Fail(res, 404, err);
            Ok(res);
        });

        // delete_files (default true): remove the partial file; for a finished download also the finished file
        // only when delete_files is explicitly true.
        svr.Post("/v2/delete", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            uint32_t id;
            bool all;
            if (!ReadId(req, body, id, all)) return Fail(res, 400, "id is required");
            if (all) return Fail(res, 400, "delete does not accept all");
            bool del = true;
            if (body.t == mj::Json::Obj && body.get("delete_files")) del = body.getBool("delete_files");
            if (req.has_param("delete_files")) del = req.get_param_value("delete_files") != "false" && req.get_param_value("delete_files") != "0";
            std::string err;
            if (!Remove(id, del, err)) return Fail(res, 404, err);
            Ok(res);
        });

        // ---- queue: priority (-100..100, higher first) and order ----
        svr.Post("/v2/priority", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            uint32_t id;
            bool all;
            if (!ReadId(req, body, id, all) || all) return Fail(res, 400, "id is required");
            int prio = 0;
            if (body.t == mj::Json::Obj && body.get("priority")) prio = (int)body.getInt("priority");
            if (req.has_param("priority")) prio = atoi(req.get_param_value("priority").c_str());
            std::string err;
            if (!SetPriority(id, prio, err)) return Fail(res, 404, err);
            Ok(res);
        });

        // {"id":N,"to":"top|bottom|up|down"} or {"id":N,"to":"pos","position":K}
        svr.Post("/v2/move", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            uint32_t id;
            bool all;
            if (!ReadId(req, body, id, all) || all) return Fail(res, 400, "id is required");
            std::string to = (body.t == mj::Json::Obj) ? body.getStr("to") : "";
            int position = (body.t == mj::Json::Obj) ? (int)body.getInt("position") : 0;
            if (req.has_param("to")) to = req.get_param_value("to");
            if (req.has_param("position")) position = atoi(req.get_param_value("position").c_str());
            if (to.empty()) to = "pos";
            std::string err;
            int np = -1;
            if (!Move(id, to, position, err, np)) return Fail(res, err == "No such download" ? 404 : 400, err);
            mj::Json j = mj::Json::object();
            j.set("ok", mj::Json::boolean(true));
            j.set("position", mj::Json::num(np));
            Reply(res, 200, j);
        });

        // top of the queue + priority above every other download + resumes it; with preemption it starts right away
        svr.Post("/v2/start_now", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json body;
            uint32_t id;
            bool all;
            if (!ReadId(req, body, id, all) || all) return Fail(res, 400, "id is required");
            std::string err;
            if (!StartNow(id, err)) return Fail(res, err == "No such download" ? 404 : 400, err);
            Ok(res);
        });

        svr.Post("/v2/settings", [](const Request &req, Response &res) {
            if (!Authorized(req, res)) return;
            mj::Json j;
            if (!mj::Json::parse(req.body, j)) return Fail(res, 400, "Invalid JSON");
            std::string err;
            if (!UpdateSettings(j, err)) return Fail(res, 400, err);
            Reply(res, 200, InfoJson());
        });

        RegisterFsRoutes(svr);
    }
}
