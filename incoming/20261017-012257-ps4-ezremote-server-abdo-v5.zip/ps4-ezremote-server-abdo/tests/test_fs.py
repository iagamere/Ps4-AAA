#!/usr/bin/env python3
# File API tests (/v2/fs/*). usage: test_fs.py <test-binary>
import json, os, shutil, signal, subprocess, sys, tempfile, time, urllib.request, urllib.parse
BIN = sys.argv[1]
work = tempfile.mkdtemp(prefix="fstest")
data = os.path.join(work, "data"); root = os.path.join(work, "root"); other = os.path.join(work, "other")
for d in (data, root, other): os.makedirs(d)
HOST = "http://127.0.0.1:7711"
p = subprocess.Popen([BIN, data, "7711"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(0.8)
res = []
def rep(n, ok, d=""):
    res.append(ok); print(("PASS " if ok else "FAIL ") + n + ("  -> " + str(d) if d else ""), flush=True)
def call(path, body=None, headers=None, method=None):
    r = urllib.request.Request(HOST + path, data=(json.dumps(body).encode() if body is not None else None), method=method or ("POST" if body is not None else "GET"), headers=headers or {})
    try:
        with urllib.request.urlopen(r, timeout=10) as f: return f.status, f.read(), dict(f.headers)
    except urllib.error.HTTPError as e: return e.code, e.read(), dict(e.headers)
def J(path, body=None, headers=None):
    s, b, h = call(path, body, headers)
    try: return s, json.loads(b)
    except Exception: return s, b
def q(op, **kw): return "/v2/fs/%s?%s" % (op, urllib.parse.urlencode(kw))
try:
    open(os.path.join(root, "a.bin"), "wb").write(bytes(range(256)) * 100)
    os.makedirs(os.path.join(root, "sub", "deep")); open(os.path.join(root, "sub", "deep", "f.txt"), "w").write("x")
    open(os.path.join(other, "secret.txt"), "w").write("secret")
    os.symlink(other, os.path.join(root, "escape"))
    s, r = J(q("list", path=root)); rep("disabled by default (403)", s == 403, s)
    J("/v2/settings", {"fs_roots": [root]})
    s, r = J("/v2/fs/roots"); rep("roots", s == 200 and r["enabled"] and r["roots"] == [root], r)
    s, r = J(q("list", path=root)); names = sorted(e["name"] for e in r["entries"]) if s == 200 else r
    rep("list", s == 200 and names == ["a.bin", "escape", "sub"], names)
    import re
    rep("list entries carry a date", s == 200 and all(re.match(r"^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d$", e.get("date", "")) for e in r["entries"]), r["entries"][0] if s == 200 else "")
    s, r = J(q("list", path=other)); rep("outside root refused", s == 403, s)
    s, r = J(q("list", path=root + "/escape")); rep("symlink escape refused", s == 403, s)
    s, r = J(q("read", path=root + "/escape/secret.txt")); rep("symlink file escape refused", s == 403, s)
    s, r = J(q("list", path=root + "/sub/../../other")); rep("dotdot refused", s == 400, s)
    s, r = J(q("list", path="relative")); rep("relative refused", s == 400, s)
    s, r = J(q("stat", path=root + "/a.bin")); rep("stat file", s == 200 and r["exists"] and r["size"] == 25600 and not r["dir"], r)
    s, r = J(q("stat", path=root + "/nope.bin")); rep("stat missing -> exists false", s == 200 and r["exists"] is False, r)
    s, r = J(q("stat", path=other + "/nope.bin")); rep("stat missing outside refused", s == 403, s)
    s, b, h = call(q("read", path=root + "/a.bin", offset=250, length=10))
    rep("read range", s == 200 and b == bytes(range(250, 256)) + bytes(range(4)) and h.get("X-File-Size") == "25600", (s, len(b)))
    s, b, h = call(q("read", path=root + "/a.bin", offset=99999, length=10)); rep("read past end empty", s == 200 and b == b"", len(b))
    s, r = J(q("read", path=root + "/sub")); rep("read dir refused", s == 400, s)
    s, r = J("/v2/fs/mkdir", {"path": root + "/n1/n2"}); rep("mkdir -p", s == 200 and os.path.isdir(root + "/n1/n2"), r)
    s, r = J("/v2/fs/rename", {"from": root + "/n1", "to": root + "/n3"}); rep("rename", s == 200 and os.path.isdir(root + "/n3/n2"), r)
    s, r = J("/v2/fs/rename", {"from": root + "/n3", "to": root + "/sub"}); rep("rename onto existing -> 409", s == 409, s)
    s, r = J("/v2/fs/rename", {"from": root + "/n3", "to": other + "/n3"}); rep("rename out of root refused", s == 403 and not os.path.exists(other + "/n3"), s)
    s, r = J("/v2/fs/delete", {"path": root + "/sub"}); rep("delete tree", s == 200 and not os.path.exists(root + "/sub"), r)
    s, r = J("/v2/fs/delete", {"path": root + "/escape"}); rep("delete symlink removes link only", s == 403 or (os.path.exists(other + "/secret.txt")), s)
    s, r = J("/v2/fs/delete", {"path": root}); rep("delete root refused", s == 400 and os.path.isdir(root), s)
    s, r = J("/v2/fs/delete", {"path": other + "/secret.txt"}); rep("delete outside refused", s == 403 and os.path.exists(other + "/secret.txt"), s)
    odd = root + "/a b+c \u0639\u0631\u0628\u064a"
    os.makedirs(odd); open(odd + "/x y.txt", "w").write("hi")
    s, r = J(q("stat", path=odd + "/x y.txt")); rep("space / plus / Arabic path", s == 200 and r["exists"] and r["size"] == 2, r)
    # token + CSRF
    J("/v2/settings", {"token": "tok"})
    s, r = J(q("list", path=root)); rep("token required", s == 401, s)
    s, r = J(q("list", path=root), headers={"X-Token": "tok"}); rep("token accepted", s == 200, s)
    s, b, h = call(q("list", path=root), headers={"X-Token": "tok", "Origin": "http://evil.example"}); rep("cross-site origin blocked", s == 403, s)
    s, r = J("/v2/settings", {"token": ""}, headers={"X-Token": "tok"})
    J("/v2/settings", {"fs_roots": ["/", "relative", root + "/../x"]}, headers={})
    s, r = J("/v2/info"); rep("'/' and bad roots not accepted", s == 200 and r["settings"]["fs_roots"] == [], r["settings"]["fs_roots"] if s == 200 else s)
    s, r = J("/v2/info"); rep("info has fs_api", r.get("fs_api") == 1, r.get("fs_api"))
finally:
    p.send_signal(signal.SIGTERM)
    try: p.wait(5)
    except Exception: p.kill()
    shutil.rmtree(work, ignore_errors=True)
print("%d/%d passed" % (sum(res), len(res))); sys.exit(0 if all(res) else 1)
