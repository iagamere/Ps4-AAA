#include "dl/engine.h"
#include "http/httplib.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cerrno>
#include <cctype>
#include <cstdarg>
#include <cstring>
#include <ctime>
#include <cmath>
#include <deque>
#include <memory>
#include <mutex>
#include <vector>

#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

namespace DL
{
    const char *kVersion = "2.0.0-abdo3";
    const char *kCompatVersion = "1.05";

    // =====================================================================================================
    // small utilities
    // =====================================================================================================
    static uint64_t NowMs()
    {
        return (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
                   std::chrono::steady_clock::now().time_since_epoch())
            .count();
    }
    static uint64_t WallUs()
    {
        return (uint64_t)std::chrono::duration_cast<std::chrono::microseconds>(
                   std::chrono::system_clock::now().time_since_epoch())
            .count();
    }

    // pthread wrapper with an explicit stack: httplib keeps a 512 KB buffer on the stack while reading a body.
    class Thread
    {
    public:
        Thread() {}
        Thread(const Thread &) = delete;
        Thread &operator=(const Thread &) = delete;
        bool start(std::function<void()> fn)
        {
            pthread_attr_t attr;
            pthread_attr_init(&attr);
            pthread_attr_setstacksize(&attr, 4u * 1024 * 1024);
            auto *f = new std::function<void()>(std::move(fn));
            int r = pthread_create(&t_, &attr, &Thread::tramp, f);
            pthread_attr_destroy(&attr);
            if (r != 0)
            {
                delete f;
                return false;
            }
            joinable_ = true;
            return true;
        }
        void join()
        {
            if (joinable_)
            {
                pthread_join(t_, nullptr);
                joinable_ = false;
            }
        }
        void detach()
        {
            if (joinable_)
            {
                pthread_detach(t_);
                joinable_ = false;
            }
        }
        bool joinable() const { return joinable_; }

    private:
        static void *tramp(void *p)
        {
            std::function<void()> *f = static_cast<std::function<void()> *>(p);
            (*f)();
            delete f;
            return nullptr;
        }
        pthread_t t_;
        bool joinable_ = false;
    };

    static void SleepMs(uint64_t ms, const std::atomic<bool> *stop = nullptr)
    {
        uint64_t end = NowMs() + ms;
        while (NowMs() < end)
        {
            if (stop && stop->load()) return;
            uint64_t left = end - NowMs();
            usleep((useconds_t)std::min<uint64_t>(left, 50) * 1000);
        }
    }

    static bool MkDirsP(const std::string &path)
    {
        if (path.empty()) return false;
        std::string cur;
        size_t pos = 0;
        while (pos != std::string::npos)
        {
            pos = path.find('/', pos + 1);
            cur = path.substr(0, pos);
            if (cur.empty()) continue;
            if (mkdir(cur.c_str(), 0777) != 0 && errno != EEXIST) return false;
        }
        return true;
    }
    static std::string DirName(const std::string &p)
    {
        size_t s = p.rfind('/');
        if (s == std::string::npos) return ".";
        if (s == 0) return "/";
        return p.substr(0, s);
    }
    static bool EndsWithNoCase(const std::string &s, const char *suffix)
    {
        size_t n = strlen(suffix);
        if (s.size() < n) return false;
        for (size_t i = 0; i < n; i++)
            if (tolower((unsigned char)s[s.size() - n + i]) != tolower((unsigned char)suffix[i])) return false;
        return true;
    }
    static bool StartsWithNoCase(const std::string &s, const char *prefix)
    {
        size_t n = strlen(prefix);
        if (s.size() < n) return false;
        for (size_t i = 0; i < n; i++)
            if (tolower((unsigned char)s[i]) != tolower((unsigned char)prefix[i])) return false;
        return true;
    }
    static Hooks g_hooks;

    // -1 when unknown (no hook installed): the free-space pre-check is skipped, and a full disk is still
    // detected when a write fails.
    static int64_t FreeBytes(const std::string &dir)
    {
        if (!g_hooks.free_bytes) return -1;
        return g_hooks.free_bytes(dir);
    }
    static void Trunc(int fd, off_t n)
    {
        if (ftruncate(fd, n) != 0) Log("ftruncate failed: %s", strerror(errno));
    }
    static bool PWriteAll(int fd, const char *d, size_t n, uint64_t off)
    {
        while (n > 0)
        {
            ssize_t w = pwrite(fd, d, n, (off_t)off);
            if (w < 0)
            {
                if (errno == EINTR) continue;
                return false;
            }
            d += w;
            n -= (size_t)w;
            off += (uint64_t)w;
        }
        return true;
    }
    static std::string HumanBytes(uint64_t b)
    {
        char buf[32];
        if (b >= (1ull << 30)) snprintf(buf, sizeof(buf), "%.2f GB", b / 1073741824.0);
        else if (b >= (1ull << 20)) snprintf(buf, sizeof(buf), "%.1f MB", b / 1048576.0);
        else snprintf(buf, sizeof(buf), "%.0f KB", b / 1024.0);
        return buf;
    }

    // =====================================================================================================
    // state
    // =====================================================================================================
    enum StopReason { SR_NONE = 0, SR_PAUSE = 1, SR_DELETE = 2, SR_REST = 3, SR_SHUTDOWN = 4, SR_RELINK = 5 };

    struct Download
    {
        uint32_t uid = 0;
        uint64_t orig_id = 0;
        Host host;           // guarded by mu while running
        std::string src_path; // guarded by mu while running
        std::string dest_path;
        uint64_t file_size = 0; // total size, 0 unknown            (g_mu)
        uint64_t timestamp = 0; // wall clock, microseconds        (g_mu)
        int failed_attempts = 0;                                    // (g_mu)
        std::string error;                                          // (g_mu)
        uint64_t next_try_ms = 0;                                   // (g_mu)
        bool paused_flag = false;                                   // (g_mu) persisted as FAILED + attempts>=max
        bool needs_link_flag = false;                               // (g_mu)

        std::atomic<int> state{ST_PENDING};
        std::atomic<uint64_t> bytes{0};
        std::atomic<int> conns{0};
        std::atomic<bool> stop{false};
        std::atomic<int> stop_reason{SR_NONE};
        std::atomic<int> link_gen{0};
        bool delete_files = false; // (g_mu)
        bool pending_delete = false; // (g_mu)

        double speed = 0;         // bytes/s (scheduler)
        uint64_t speed_bytes = 0;
        uint64_t speed_ms = 0;
        uint64_t legacy_bytes = 0;
        bool running = false; // manager thread alive (g_mu)
        Thread mgr;

        // chunk state, guarded by mu
        std::mutex mu;
        uint64_t chunk_size = 0;      // 0: not chunked
        std::vector<uint8_t> chunks;  // 0 none, 1 claimed, 2 done
        int fd = -1;                  // guarded by fd_mu
        std::mutex fd_mu;
        std::string mode;             // "", "single", "chunked", "legacy" (info only)
    };
    typedef std::shared_ptr<Download> DownloadPtr;

    static std::mutex g_mu;
    static std::vector<DownloadPtr> g_list;
    static Settings g_set;
    static std::string g_dir, g_hist_path, g_set_path, g_log_path;
    static std::atomic<bool> g_run{false};
    static std::atomic<bool> g_rest{false};
    static std::atomic<bool> g_dirty{false};
    static std::atomic<int> g_total_conns{0};
    static std::mutex g_legacy_mu;
    static uint32_t g_next_uid = 1;
    static Thread g_sched;

    static Settings SettingsCopy()
    {
        std::lock_guard<std::mutex> lk(g_mu);
        return g_set;
    }

    // ---------------- log ----------------
    static std::mutex g_log_mu;
    static std::deque<std::string> g_log;
    void Log(const char *fmt, ...)
    {
        char msg[600];
        va_list ap;
        va_start(ap, fmt);
        vsnprintf(msg, sizeof(msg), fmt, ap);
        va_end(ap);
        long long t = (long long)time(nullptr);
        int sod = (int)(t % 86400);
        char line[700];
        snprintf(line, sizeof(line), "[%02d:%02d:%02d UTC] %s", sod / 3600, (sod / 60) % 60, sod % 60, msg);
        std::lock_guard<std::mutex> lk(g_log_mu);
        g_log.push_back(line);
        if (g_log.size() > 400) g_log.pop_front();
        if (!g_log_path.empty())
        {
            struct stat st;
            if (stat(g_log_path.c_str(), &st) == 0 && st.st_size > 512 * 1024)
            {
                std::string old = g_log_path + ".old";
                rename(g_log_path.c_str(), old.c_str());
            }
            FILE *f = fopen(g_log_path.c_str(), "a");
            if (f)
            {
                fprintf(f, "%s\n", line);
                fclose(f);
            }
        }
    }
    std::string LogTail(int lines)
    {
        std::lock_guard<std::mutex> lk(g_log_mu);
        std::string r;
        int n = (int)g_log.size();
        int from = std::max(0, n - std::max(1, lines));
        for (int i = from; i < n; i++)
        {
            r += g_log[i];
            r += '\n';
        }
        return r;
    }

    static void Notify(const std::string &m)
    {
        if (g_hooks.notify) g_hooks.notify(m);
    }
    static std::string BaseName(const std::string &p)
    {
        size_t s = p.rfind('/');
        return s == std::string::npos ? p : p.substr(s + 1);
    }

    // =====================================================================================================
    // persistence (atomic write, tolerant read)
    // =====================================================================================================
    static const char *kStateNames[] = {"pending", "downloading", "resuming", "failed", "done", "paused", "needs_link", "stopping"};

    static int LegacyStateOf(int s)
    {
        if (s == ST_PAUSED || s == ST_NEEDS_LINK) return ST_FAILED;
        if (s == ST_STOPPING) return ST_DOWNLOADING;
        return s;
    }

    static uint64_t DoneBytesLocked(Download &d, uint64_t total)
    {
        uint64_t sum = 0;
        for (size_t i = 0; i < d.chunks.size(); i++)
            if (d.chunks[i] == 2)
            {
                uint64_t a = (uint64_t)i * d.chunk_size;
                uint64_t b = std::min<uint64_t>(total, a + d.chunk_size);
                sum += b - a;
            }
        return sum;
    }

    static bool WriteFileAtomic(const std::string &path, const std::string &data)
    {
        std::string tmp = path + ".new";
        FILE *f = fopen(tmp.c_str(), "wb");
        if (!f) return false;
        bool ok = fwrite(data.data(), 1, data.size(), f) == data.size();
        ok = (fflush(f) == 0) && ok;
        fsync(fileno(f));
        fclose(f);
        if (!ok)
        {
            unlink(tmp.c_str());
            return false;
        }
        std::string bak = path + ".bak";
        rename(path.c_str(), bak.c_str());
        if (rename(tmp.c_str(), path.c_str()) != 0) return false;
        return true;
    }
    static bool ReadFile(const std::string &path, std::string &out)
    {
        FILE *f = fopen(path.c_str(), "rb");
        if (!f) return false;
        char buf[8192];
        size_t n;
        out.clear();
        while ((n = fread(buf, 1, sizeof(buf), f)) > 0)
        {
            out.append(buf, n);
            if (out.size() > 32u * 1024 * 1024)
            {
                fclose(f);
                return false;
            }
        }
        fclose(f);
        return true;
    }

    static std::string Enc(const std::string &s) { return (g_hooks.encrypt && !s.empty()) ? g_hooks.encrypt(s) : s; }
    static std::string Dec(const std::string &s)
    {
        if (!g_hooks.decrypt || s.empty()) return s;
        std::string r = g_hooks.decrypt(s);
        return r;
    }

    static void SaveNow()
    {
        std::vector<DownloadPtr> snap;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            snap = g_list;
        }
        mj::Json arr = mj::Json::array();
        uint64_t now_us = WallUs();
        const uint64_t kRetentionUs = 1209600000000ull; // 14 days like the original
        for (auto &d : snap)
        {
            // snapshot chunk state first, then fsync, so that every chunk written down as done is really on disk
            std::vector<uint8_t> chunks;
            uint64_t csize = 0;
            {
                std::lock_guard<std::mutex> lk(d->mu);
                chunks = d->chunks;
                csize = d->chunk_size;
            }
            {
                std::lock_guard<std::mutex> lk(d->fd_mu);
                if (d->fd >= 0) fsync(d->fd);
            }
            std::lock_guard<std::mutex> lk(g_mu);
            int st = d->state.load();
            bool finished = (st == ST_SUCCESS) || (st == ST_FAILED && d->failed_attempts >= g_set.max_attempts);
            if (finished && now_us > d->timestamp && now_us - d->timestamp > kRetentionUs) continue;
            if (d->pending_delete) continue;

            mj::Json e = mj::Json::object();
            Host h;
            {
                std::lock_guard<std::mutex> lk2(d->mu);
                h = d->host;
                e.set("src_path", mj::Json::str(d->src_path));
            }
            e.set("type", mj::Json::num(h.type));
            e.set("url", mj::Json::str(h.url));
            if (!h.http_server_type.empty()) e.set("http_server_type", mj::Json::str(h.http_server_type));
            e.set("username", mj::Json::str(h.username));
            e.set("password", mj::Json::str(Enc(h.password)));
            e.set("dest_path", mj::Json::str(d->dest_path));
            e.set("file_size", mj::Json::num((int64_t)d->file_size));

            uint64_t done = 0;
            if (csize && !chunks.empty() && d->file_size)
            {
                for (size_t i = 0; i < chunks.size(); i++)
                    if (chunks[i] == 2)
                    {
                        uint64_t a = (uint64_t)i * csize;
                        done += std::min<uint64_t>(d->file_size, a + csize) - a;
                    }
            }
            else if (d->host.type != g_hooks.filehost_type)
                done = d->legacy_bytes;
            else
                done = d->bytes.load();
            if (st == ST_SUCCESS) done = d->file_size ? d->file_size : done;
            e.set("bytes_transfered", mj::Json::num((int64_t)done));

            // the original server only knows 0..4; paused / needs_link are stored as FAILED with attempts >= max
            int out_state = LegacyStateOf(st);
            int attempts = d->failed_attempts;
            if (st == ST_PAUSED || st == ST_NEEDS_LINK) attempts = std::max(attempts, g_set.max_attempts);
            if (out_state == ST_DOWNLOADING || out_state == ST_RESUMED) out_state = ST_DOWNLOADING;
            e.set("state", mj::Json::num(out_state));
            e.set("id", mj::Json::num((int64_t)d->orig_id));
            e.set("timestamp", mj::Json::num((int64_t)d->timestamp));
            e.set("failed_attempts", mj::Json::num(attempts));
            // extras (the original ignores unknown fields)
            e.set("uid", mj::Json::num(d->uid));
            if (st == ST_PAUSED) e.set("paused", mj::Json::boolean(true));
            if (st == ST_NEEDS_LINK) e.set("needs_link", mj::Json::boolean(true));
            if (!d->error.empty()) e.set("error", mj::Json::str(d->error));
            if (csize && !chunks.empty())
            {
                size_t upto = 0;
                while (upto < chunks.size() && chunks[upto] == 2) upto++;
                e.set("chunk_size", mj::Json::num((int64_t)csize));
                e.set("done_upto", mj::Json::num((int64_t)upto));
                mj::Json extra = mj::Json::array();
                for (size_t i = upto; i < chunks.size(); i++)
                    if (chunks[i] == 2) extra.push(mj::Json::num((int64_t)i));
                e.set("done_extra", extra);
            }
            arr.push(e);
        }
        MkDirsP(g_dir);
        if (!WriteFileAtomic(g_hist_path, arr.dump())) Log("WARNING: could not write %s", g_hist_path.c_str());
    }

    static void SaveSettings()
    {
        Settings s = SettingsCopy();
        mj::Json j = mj::Json::object();
        j.set("max_parallel", mj::Json::num(s.max_parallel));
        j.set("max_conns_per_download", mj::Json::num(s.max_conns_per_download));
        j.set("max_total_conns", mj::Json::num(s.max_total_conns));
        j.set("auto_conns", mj::Json::boolean(s.auto_conns));
        j.set("fixed_conns", mj::Json::num(s.fixed_conns));
        j.set("chunk_mb", mj::Json::num(s.chunk_mb));
        j.set("max_attempts", mj::Json::num(s.max_attempts));
        j.set("notify_start", mj::Json::boolean(s.notify_start));
        j.set("notify_complete", mj::Json::boolean(s.notify_complete));
        j.set("notify_fail", mj::Json::boolean(s.notify_fail));
        j.set("token", mj::Json::str(s.token));
        MkDirsP(g_dir);
        WriteFileAtomic(g_set_path, j.dump());
    }

    static int Clamp(int64_t v, int lo, int hi) { return (int)std::max<int64_t>(lo, std::min<int64_t>(hi, v)); }

    static void ApplySettings(const mj::Json &j, Settings &s)
    {
        if (j.get("max_parallel")) s.max_parallel = Clamp(j.getInt("max_parallel"), 1, 6);
        if (j.get("max_conns_per_download")) s.max_conns_per_download = Clamp(j.getInt("max_conns_per_download"), 1, 16);
        if (j.get("max_total_conns")) s.max_total_conns = Clamp(j.getInt("max_total_conns"), 1, 32);
        if (j.get("auto_conns")) s.auto_conns = j.getBool("auto_conns");
        if (j.get("fixed_conns")) s.fixed_conns = Clamp(j.getInt("fixed_conns"), 1, 16);
        if (j.get("chunk_mb")) s.chunk_mb = Clamp(j.getInt("chunk_mb"), 1, 64);
        if (j.get("max_attempts")) s.max_attempts = Clamp(j.getInt("max_attempts"), 1, 20);
        if (j.get("notify_start")) s.notify_start = j.getBool("notify_start");
        if (j.get("notify_complete")) s.notify_complete = j.getBool("notify_complete");
        if (j.get("notify_fail")) s.notify_fail = j.getBool("notify_fail");
        if (j.get("token")) s.token = j.getStr("token");
    }

    static void LoadSettings()
    {
        std::string txt;
        mj::Json j;
        if (ReadFile(g_set_path, txt) && mj::Json::parse(txt, j) && j.t == mj::Json::Obj)
        {
            std::lock_guard<std::mutex> lk(g_mu);
            ApplySettings(j, g_set);
        }
    }

    static bool ParseHistory(const std::string &txt)
    {
        mj::Json arr;
        if (!mj::Json::parse(txt, arr) || arr.t != mj::Json::Arr) return false;
        std::lock_guard<std::mutex> lk(g_mu);
        for (auto &e : arr.a)
        {
            if (e.t != mj::Json::Obj) continue;
            auto d = std::make_shared<Download>();
            d->host.type = (int)e.getInt("type");
            d->host.url = e.getStr("url");
            d->host.http_server_type = e.getStr("http_server_type");
            d->host.username = e.getStr("username");
            d->host.password = Dec(e.getStr("password"));
            d->src_path = e.getStr("src_path");
            d->dest_path = e.getStr("dest_path");
            if (d->dest_path.empty()) continue;
            d->file_size = (uint64_t)e.getInt("file_size");
            d->orig_id = (uint64_t)e.getInt("id");
            d->timestamp = (uint64_t)e.getInt("timestamp");
            if (d->timestamp == 0) d->timestamp = WallUs();
            d->failed_attempts = (int)e.getInt("failed_attempts");
            d->error = e.getStr("error");
            uint64_t done = (uint64_t)e.getInt("bytes_transfered");
            int st = (int)e.getInt("state");
            uint32_t uid = (uint32_t)e.getInt("uid");
            if (uid == 0 || uid >= 0x7fffffff) uid = 0;
            for (auto &o : g_list)
                if (o->uid == uid) uid = 0;
            d->uid = uid ? uid : g_next_uid;
            g_next_uid = std::max(g_next_uid, d->uid + 1);

            d->chunk_size = (uint64_t)e.getInt("chunk_size");
            if (d->chunk_size && d->file_size)
            {
                size_t n = (size_t)((d->file_size + d->chunk_size - 1) / d->chunk_size);
                if (n > 0 && n < 4000000)
                {
                    d->chunks.assign(n, 0);
                    size_t upto = (size_t)std::min<int64_t>((int64_t)n, e.getInt("done_upto"));
                    for (size_t i = 0; i < upto; i++) d->chunks[i] = 2;
                    const mj::Json *ex = e.get("done_extra");
                    if (ex && ex->t == mj::Json::Arr)
                        for (auto &x : ex->a)
                            if (x.t == mj::Json::Int && x.i >= 0 && (size_t)x.i < n) d->chunks[(size_t)x.i] = 2;
                }
                else
                    d->chunk_size = 0;
            }
            else
                d->chunk_size = 0;

            if (st == ST_SUCCESS)
            {
                d->state = ST_SUCCESS;
                d->bytes = d->file_size ? d->file_size : done;
            }
            else if (st == ST_FAILED)
            {
                if (e.getBool("paused") && d->failed_attempts >= g_set.max_attempts) d->state = ST_PAUSED;
                else if (e.getBool("needs_link") && d->failed_attempts >= g_set.max_attempts) d->state = ST_NEEDS_LINK;
                else d->state = ST_FAILED; // attempts < max: the scheduler retries it
                d->bytes = done;
                d->next_try_ms = NowMs() + 3000;
            }
            else
            {
                d->state = ST_PENDING; // was downloading when the server stopped: resume
                d->bytes = done;
            }
            if (!d->chunks.empty() && d->state != ST_SUCCESS) d->bytes = DoneBytesLocked(*d, d->file_size);
            g_list.push_back(d);
        }
        return true;
    }

    static void LoadHistory()
    {
        std::string txt;
        bool exists = ReadFile(g_hist_path, txt);
        if (exists && ParseHistory(txt)) return;
        if (exists)
        {
            Log("History file is corrupt, trying the backup");
            char name[600];
            snprintf(name, sizeof(name), "%s.corrupt-%lld", g_hist_path.c_str(), (long long)time(nullptr));
            rename(g_hist_path.c_str(), name);
        }
        if (ReadFile(g_hist_path + ".bak", txt) && ParseHistory(txt))
        {
            Log("Loaded the history from the backup copy");
            return;
        }
    }

    // =====================================================================================================
    // HTTP helpers
    // =====================================================================================================
    static std::unique_ptr<httplib::Client> MakeClient(const std::string &host)
    {
        auto c = std::unique_ptr<httplib::Client>(new httplib::Client(host));
        c->set_follow_location(true);
        c->set_keep_alive(true);
        c->set_connection_timeout(15);
        c->set_read_timeout(30);
#ifdef CPPHTTPLIB_OPENSSL_SUPPORT
        c->enable_server_certificate_verification(false); // same behaviour as the original server
#endif
        return c;
    }

    static bool ParseContentRangeTotal(const std::string &cr, uint64_t &total)
    {
        size_t s = cr.find('/');
        if (s == std::string::npos) return false;
        std::string t = cr.substr(s + 1);
        if (t.empty() || t[0] == '*') return false;
        total = strtoull(t.c_str(), nullptr, 10);
        return total > 0;
    }
    static bool ParseContentRangeStart(const std::string &cr, uint64_t &start)
    {
        size_t s = cr.find("bytes");
        if (s == std::string::npos) return false;
        s += 5;
        while (s < cr.size() && (cr[s] == ' ' || cr[s] == '=')) s++;
        if (s >= cr.size() || !isdigit((unsigned char)cr[s])) return false;
        start = strtoull(cr.c_str() + s, nullptr, 10);
        return true;
    }

    struct ProbeRes
    {
        int status = 0;
        bool net_err = false;
        std::string net_msg;
        bool range = false;
        uint64_t total = 0;
        bool html = false;
    };

    static ProbeRes Probe(const std::string &host, const std::string &path, bool dest_is_html)
    {
        ProbeRes pr;
        auto cli = MakeClient(host);
        httplib::Headers h = {{"Range", "bytes=0-0"}};
        auto res = cli->Get(path.c_str(), h,
                            [&](const httplib::Response &r) {
                                pr.status = r.status;
                                std::string ct = r.get_header_value("Content-Type");
                                pr.html = !dest_is_html && StartsWithNoCase(ct, "text/html");
                                if (r.status == 206)
                                {
                                    uint64_t t = 0;
                                    if (ParseContentRangeTotal(r.get_header_value("Content-Range"), t))
                                    {
                                        pr.range = true;
                                        pr.total = t;
                                    }
                                }
                                else if (r.status == 200)
                                {
                                    std::string cl = r.get_header_value("Content-Length");
                                    if (!cl.empty()) pr.total = strtoull(cl.c_str(), nullptr, 10);
                                }
                                return r.status == 206; // do not read a whole file just to probe it
                            },
                            [&](const char *, size_t) { return true; });
        if (pr.status == 0)
        {
            pr.net_err = true;
            pr.net_msg = httplib::to_string(res.error());
        }
        return pr;
    }

    enum Outcome { OC_SUCCESS, OC_STOPPED, OC_RETRY, OC_FATAL, OC_NEEDS_LINK, OC_FALLBACK_STREAM };

    // =====================================================================================================
    // chunked multi-connection download
    // =====================================================================================================
    struct RunCtx
    {
        int fd = -1;
        uint64_t total = 0;
        uint64_t C = 0;
        std::atomic<uint64_t> last_progress{0};
        std::atomic<int> refused{0};
        std::atomic<bool> disk_err{false};
        std::atomic<bool> range_broken{false};
        std::atomic<int> gave_up{0};
        std::atomic<bool> busy_hint{false};
        std::atomic<bool> abort{false};
        std::mutex mu;
        std::string last_err;
        void SetErr(const std::string &e)
        {
            std::lock_guard<std::mutex> lk(mu);
            last_err = e;
        }
        std::string GetErr()
        {
            std::lock_guard<std::mutex> lk(mu);
            return last_err;
        }
    };

    struct Worker
    {
        Thread th;
        std::atomic<bool> quit{false};
        std::atomic<bool> finished{false};
    };

    static void ChunkWorker(DownloadPtr dl, Worker *w, RunCtx *ctx, bool dest_is_html)
    {
        std::unique_ptr<httplib::Client> cli;
        std::string cli_host;
        int cli_gen = -1;
        int consec = 0;
        uint64_t backoff = 1000;
        while (!dl->stop.load() && !ctx->abort.load() && !w->quit.load())
        {
            int64_t idx = -1;
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                for (size_t i = 0; i < dl->chunks.size(); i++)
                    if (dl->chunks[i] == 0)
                    {
                        dl->chunks[i] = 1;
                        idx = (int64_t)i;
                        break;
                    }
            }
            if (idx < 0) break;

            std::string host, path;
            int gen;
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                host = dl->host.url;
                path = dl->src_path;
                gen = dl->link_gen.load();
            }
            if (!cli || gen != cli_gen || host != cli_host)
            {
                cli = MakeClient(host);
                cli_host = host;
                cli_gen = gen;
            }
            uint64_t a = (uint64_t)idx * ctx->C;
            uint64_t b = std::min<uint64_t>(ctx->total - 1, a + ctx->C - 1);
            uint64_t len = b - a + 1;
            uint64_t got = 0;
            int status = 0;
            bool bad_hdr = false;
            char range[64];
            snprintf(range, sizeof(range), "bytes=%llu-%llu", (unsigned long long)a, (unsigned long long)b);
            httplib::Headers hdr = {{"Range", range}};

            auto res = cli->Get(path.c_str(), hdr,
                                [&](const httplib::Response &r) {
                                    status = r.status;
                                    if (r.status != 206) return false;
                                    if (!dest_is_html && StartsWithNoCase(r.get_header_value("Content-Type"), "text/html"))
                                    {
                                        bad_hdr = true;
                                        return false;
                                    }
                                    uint64_t st = 0;
                                    if (ParseContentRangeStart(r.get_header_value("Content-Range"), st) && st != a)
                                    {
                                        bad_hdr = true;
                                        return false;
                                    }
                                    return true;
                                },
                                [&](const char *data, size_t n) {
                                    if (dl->stop.load() || ctx->abort.load()) return false;
                                    if (got + n > len) n = (size_t)(len - got); // never write past the chunk
                                    if (n > 0)
                                    {
                                        if (!PWriteAll(ctx->fd, data, n, a + got))
                                        {
                                            ctx->disk_err = true;
                                            return false;
                                        }
                                        got += n;
                                        dl->bytes += n;
                                        ctx->last_progress = NowMs();
                                    }
                                    return true; // never abort a finished chunk: aborting closes the keep-alive connection
                                });

            bool ok = (got == len) && status == 206 && !bad_hdr;
            if (ok)
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                dl->chunks[(size_t)idx] = 2;
                consec = 0;
                backoff = 1000;
                continue;
            }

            // failure: give the chunk back
            dl->bytes -= got;
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                dl->chunks[(size_t)idx] = 0;
            }
            if (dl->stop.load() || ctx->abort.load() || w->quit.load()) break;
            if (ctx->disk_err.load())
            {
                ctx->SetErr("Disk write failed (disk full or storage error)");
                break;
            }
            if (bad_hdr)
            {
                ctx->SetErr("The server answered with a web page instead of the file");
                ctx->refused++;
                break;
            }
            if (status == 200)
            {
                ctx->range_broken = true; // the server ignores Range after all
                break;
            }
            if (status == 401 || status == 403 || status == 404 || status == 410)
            {
                char m[64];
                snprintf(m, sizeof(m), "HTTP %d on a chunk request", status);
                ctx->SetErr(m);
                ctx->refused++;
                break;
            }
            // transient: 416 (should not happen), 429, 5xx, network errors
            consec++;
            char m[160];
            if (status)
                snprintf(m, sizeof(m), "HTTP %d", status);
            else
                snprintf(m, sizeof(m), "network: %s", httplib::to_string(res.error()).c_str());
            ctx->SetErr(m);
            if (status == 429 || status == 503) ctx->busy_hint = true;
            cli.reset(); // fresh connection next time
            if (consec >= 6)
            {
                ctx->gave_up++;
                break;
            }
            SleepMs(backoff, &dl->stop);
            backoff = std::min<uint64_t>(backoff * 2, 15000);
        }
    }

    static Outcome RunChunked(const DownloadPtr &dl, int fd, uint64_t total, bool dest_is_html, std::string &err)
    {
        Settings S = SettingsCopy();
        RunCtx ctx;
        ctx.fd = fd;
        ctx.total = total;
        ctx.C = dl->chunk_size;
        ctx.last_progress = NowMs();
        std::vector<std::unique_ptr<Worker>> workers;

        int target = S.auto_conns ? 1 : std::min(S.fixed_conns, S.max_conns_per_download);
        int prev_target = 1;
        bool ever_reverted = false, baseline = false, win_started = false;
        double prev_speed = 0;
        uint64_t last_change = NowMs(), win_t = 0, win_b = 0, lock_until = 0;
        bool locked_forever = false;
        int single_refusals = 0;
        uint64_t refusal_bytes = 0, spawn_not_before = 0;
        Outcome out = OC_SUCCESS;

        auto spawn = [&]() {
            auto w = std::unique_ptr<Worker>(new Worker());
            Worker *wp = w.get();
            g_total_conns++;
            dl->conns++;
            bool started = w->th.start([dl, wp, &ctx, dest_is_html]() {
                ChunkWorker(dl, wp, &ctx, dest_is_html);
                g_total_conns--;
                dl->conns--;
                wp->finished = true;
            });
            if (!started)
            {
                g_total_conns--;
                dl->conns--;
                return;
            }
            workers.push_back(std::move(w));
        };
        auto retire_to = [&](int n) {
            int live = 0;
            for (auto &w : workers)
                if (!w->finished.load() && !w->quit.load()) live++;
            for (int i = (int)workers.size() - 1; i >= 0 && live > n; i--)
                if (!workers[i]->finished.load() && !workers[i]->quit.load())
                {
                    workers[i]->quit = true;
                    live--;
                }
        };

        while (true)
        {
            SleepMs(200, &dl->stop);
            if (dl->stop.load())
            {
                out = OC_STOPPED;
                break;
            }
            uint64_t now = NowMs();
            int live = 0;
            for (auto &w : workers)
                if (!w->finished.load()) live++;

            size_t done = 0, unclaimed = 0;
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                for (auto c : dl->chunks)
                {
                    if (c == 2) done++;
                    else if (c == 0) unclaimed++;
                }
            }
            size_t nchunks = dl->chunks.size();
            if (done == nchunks)
            {
                out = OC_SUCCESS;
                break;
            }
            if (ctx.disk_err.load())
            {
                err = ctx.GetErr();
                out = OC_FATAL;
                break;
            }
            if (ctx.range_broken.load())
            {
                out = OC_FALLBACK_STREAM;
                break;
            }
            int refused = ctx.refused.exchange(0);
            if (refused > 0)
            {
                if (target > 1 || live > 1)
                {
                    Log("dl %u: server refuses parallel requests (%s) -> 1 connection", dl->uid, ctx.GetErr().c_str());
                    target = 1;
                    prev_target = 1;
                    locked_forever = true;
                    retire_to(1);
                }
                else
                {
                    // a refusal can be transient (the host still counts the connection we just closed): retry twice
                    if (dl->bytes.load() > refusal_bytes) single_refusals = 0;
                    refusal_bytes = dl->bytes.load();
                    single_refusals++;
                    if (single_refusals >= 3)
                    {
                        err = "The link no longer works: " + ctx.GetErr() + ". Send the link again (same destination) and it will continue.";
                        out = OC_NEEDS_LINK;
                        break;
                    }
                    Log("dl %u: request refused (%s), retrying (%d/2)", dl->uid, ctx.GetErr().c_str(), single_refusals);
                    spawn_not_before = now + 2500;
                }
            }
            if (live > 0 && now - ctx.last_progress.load() > 45000)
            {
                err = "No data for 45 seconds";
                out = OC_RETRY;
                break;
            }
            if (live == 0 && ctx.gave_up.load() > 0 && done < nchunks)
            {
                err = ctx.GetErr();
                out = OC_RETRY;
                break;
            }

            // ------------- automatic tuner -------------
            int ceiling = std::min<int>(S.max_conns_per_download, (int)(nchunks - done));
            if (S.auto_conns)
            {
                if (!win_started && now - last_change >= 2000 && live >= std::min(target, ceiling))
                {
                    win_started = true;
                    win_t = now;
                    win_b = dl->bytes.load();
                }
                if (win_started && now - win_t >= 6000 && !locked_forever && now >= lock_until && live >= std::min(target, ceiling))
                {
                    double spd = (double)(dl->bytes.load() - win_b) / ((now - win_t) / 1000.0);
                    if (!baseline)
                    {
                        baseline = true;
                        prev_speed = spd;
                        if (target < ceiling)
                        {
                            prev_target = target;
                            target = std::min(ceiling, target < 4 && !ever_reverted ? target * 2 : target + 1);
                            Log("dl %u: baseline %.2f MB/s with %d conn -> trying %d", dl->uid, spd / 1048576.0, prev_target, target);
                        }
                    }
                    else if (spd >= prev_speed * 1.12)
                    {
                        Log("dl %u: %d conn = %.2f MB/s (was %.2f) accepted", dl->uid, target, spd / 1048576.0, prev_speed / 1048576.0);
                        prev_speed = spd;
                        if (target < ceiling)
                        {
                            prev_target = target;
                            target = std::min(ceiling, target < 4 && !ever_reverted ? target * 2 : target + 1);
                        }
                    }
                    else
                    {
                        Log("dl %u: %d conn = %.2f MB/s, no real gain over %d conn (%.2f) -> back to %d", dl->uid, target, spd / 1048576.0,
                            prev_target, prev_speed / 1048576.0, prev_target);
                        target = prev_target;
                        ever_reverted = true;
                        lock_until = now + 120000;
                        baseline = false; // re-measure after the lock
                        retire_to(target);
                    }
                    last_change = now;
                    win_started = false;
                }
            }
            if (target > ceiling) target = std::max(1, ceiling);

            // ------------- spawn -------------
            while (live < target && now >= spawn_not_before && (int)g_total_conns.load() < S.max_total_conns && unclaimed > 0)
            {
                spawn();
                live++;
                unclaimed--;
                last_change = now;
                win_started = false;
            }
        }

        // stop and join all workers (abort makes in-flight receivers return immediately)
        ctx.abort = true;
        for (auto &w : workers) w->quit = true;
        for (auto &w : workers) w->th.join();
        if (out == OC_RETRY && err.empty()) err = ctx.GetErr();
        return out;
    }

    // =====================================================================================================
    // single-stream download (small files, servers without Range)
    // =====================================================================================================
    static Outcome RunStream(const DownloadPtr &dl, int fd, uint64_t off, bool range_ok, bool dest_is_html, uint64_t &total, std::string &err, bool &needs_reset)
    {
        std::string host, path;
        {
            std::lock_guard<std::mutex> lk(dl->mu);
            host = dl->host.url;
            path = dl->src_path;
        }
        auto cli = MakeClient(host);
        httplib::Headers hdr;
        if (off > 0 && range_ok)
        {
            char r[64];
            snprintf(r, sizeof(r), "bytes=%llu-", (unsigned long long)off);
            hdr.emplace("Range", r);
        }
        else
            off = 0;
        uint64_t got = 0;
        int status = 0;
        bool restart = false, html = false;
        uint64_t expect_total = 0;
        dl->bytes = off;
        auto res = cli->Get(path.c_str(), hdr,
                            [&](const httplib::Response &r) {
                                status = r.status;
                                if (r.status == 200 && off > 0)
                                {
                                    restart = true; // server ignored our Range: start over
                                    return false;
                                }
                                if (r.status != 200 && r.status != 206) return false;
                                if (!dest_is_html && StartsWithNoCase(r.get_header_value("Content-Type"), "text/html"))
                                {
                                    html = true;
                                    return false;
                                }
                                std::string cl = r.get_header_value("Content-Length");
                                if (!cl.empty()) expect_total = off + strtoull(cl.c_str(), nullptr, 10);
                                return true;
                            },
                            [&](const char *data, size_t n) {
                                if (dl->stop.load()) return false;
                                if (!PWriteAll(fd, data, n, off + got))
                                {
                                    err = "Disk write failed (disk full or storage error)";
                                    return false;
                                }
                                got += n;
                                dl->bytes += n;
                                return true;
                            });
        if (dl->stop.load()) return OC_STOPPED;
        if (!err.empty()) return OC_FATAL;
        if (restart)
        {
            needs_reset = true;
            return OC_RETRY;
        }
        if (html)
        {
            err = "The link returned a web page instead of a file (expired link, quota exceeded or login page)";
            return OC_NEEDS_LINK;
        }
        if (status == 401 || status == 403 || status == 404 || status == 410)
        {
            char m[200];
            snprintf(m, sizeof(m), "HTTP %d: the link is expired or forbidden. Send the link again (same destination) and it will continue.", status);
            err = m;
            return OC_NEEDS_LINK;
        }
        if (status != 200 && status != 206)
        {
            char m[100];
            if (status) snprintf(m, sizeof(m), "HTTP %d", status);
            else snprintf(m, sizeof(m), "network: %s", httplib::to_string(res.error()).c_str());
            err = m;
            return OC_RETRY;
        }
        if (!res)
        {
            err = std::string("network: ") + httplib::to_string(res.error());
            return OC_RETRY;
        }
        uint64_t have = off + got;
        if (total == 0) total = expect_total ? expect_total : have;
        if (have != total)
        {
            char m[160];
            snprintf(m, sizeof(m), "Incomplete: got %llu of %llu bytes", (unsigned long long)have, (unsigned long long)total);
            err = m;
            return OC_RETRY;
        }
        return OC_SUCCESS;
    }

    // =====================================================================================================
    // one download from start to finish (manager thread)
    // =====================================================================================================
    static Outcome RunHttp(const DownloadPtr &dl, std::string &err)
    {
        Settings S = SettingsCopy();
        std::string tmp = dl->dest_path + ".tmp";
        std::string dir = DirName(dl->dest_path);
        if (!MkDirsP(dir))
        {
            err = "Cannot create the folder " + dir;
            return OC_FATAL;
        }
        std::string host, path;
        {
            std::lock_guard<std::mutex> lk(dl->mu);
            host = dl->host.url;
            path = dl->src_path;
        }
        if (host.empty() || path.empty())
        {
            err = "Missing link";
            return OC_FATAL;
        }
        if (path[0] != '/') path = "/" + path;
        bool dest_is_html = EndsWithNoCase(dl->dest_path, ".html") || EndsWithNoCase(dl->dest_path, ".htm");

        ProbeRes pr = Probe(host, path, dest_is_html);
        if (dl->stop.load()) return OC_STOPPED;
        if (pr.net_err)
        {
            err = "network: " + pr.net_msg;
            return OC_RETRY;
        }
        if (pr.html)
        {
            err = "The link returned a web page instead of a file (expired link, quota exceeded or login page)";
            return OC_NEEDS_LINK;
        }
        if (pr.status == 401 || pr.status == 403 || pr.status == 404 || pr.status == 410)
        {
            char m[200];
            snprintf(m, sizeof(m), "HTTP %d: the link is expired or forbidden. Send the link again (same destination) and it will continue.", pr.status);
            err = m;
            return OC_NEEDS_LINK;
        }
        if (pr.status != 200 && pr.status != 206)
        {
            char m[64];
            snprintf(m, sizeof(m), "HTTP %d", pr.status);
            err = m;
            return OC_RETRY;
        }

        uint64_t total = pr.total;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            if (total) dl->file_size = total;
            else total = 0;
        }
        uint64_t C = (uint64_t)S.chunk_mb << 20;
        bool chunked = pr.range && total >= 2 * C && std::max(S.max_conns_per_download, S.fixed_conns) > 1;

        int fd = open(tmp.c_str(), O_RDWR | O_CREAT, 0666);
        if (fd < 0)
        {
            err = std::string("Cannot open ") + tmp + ": " + strerror(errno);
            return OC_FATAL;
        }
        {
            std::lock_guard<std::mutex> lk(dl->fd_mu);
            dl->fd = fd;
        }
        auto close_fd = [&]() {
            std::lock_guard<std::mutex> lk(dl->fd_mu);
            if (dl->fd >= 0)
            {
                fsync(dl->fd);
                close(dl->fd);
                dl->fd = -1;
            }
        };
        struct stat st;
        fstat(fd, &st);
        uint64_t have_tmp = (uint64_t)st.st_size;

        if (total)
        {
            if (have_tmp > total)
            {
                Trunc(fd, 0);
                have_tmp = 0;
                std::lock_guard<std::mutex> lk(dl->mu);
                dl->chunks.clear();
                dl->chunk_size = 0;
            }
            int64_t freeb = FreeBytes(dir);
            uint64_t need = total - std::min(have_tmp, total);
            if (freeb >= 0 && need + (64ull << 20) > (uint64_t)freeb)
            {
                err = "Not enough free space: need " + HumanBytes(need) + ", free " + HumanBytes((uint64_t)freeb);
                close_fd();
                return OC_FATAL;
            }
        }

        Outcome oc = OC_SUCCESS;
        bool use_stream = !chunked;
        if (chunked)
        {
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                size_t n = (size_t)((total + C - 1) / C);
                bool valid = dl->chunk_size && dl->chunks.size() == (size_t)((total + dl->chunk_size - 1) / dl->chunk_size);
                if (!valid)
                {
                    // start from a sequential prefix (the original server and our own stream mode write sequentially)
                    dl->chunk_size = C;
                    dl->chunks.assign(n, 0);
                    uint64_t prefix = have_tmp / C;
                    for (uint64_t i = 0; i < prefix && i < n; i++) dl->chunks[(size_t)i] = 2;
                }
                // every chunk marked done must be physically in the file
                uint64_t need_size = 0;
                for (size_t i = 0; i < dl->chunks.size(); i++)
                    if (dl->chunks[i] == 2) need_size = std::max<uint64_t>(need_size, std::min<uint64_t>(total, ((uint64_t)i + 1) * dl->chunk_size));
                if (have_tmp < need_size)
                {
                    Log("dl %u: partial file is smaller than recorded progress, restarting", dl->uid);
                    std::fill(dl->chunks.begin(), dl->chunks.end(), 0);
                }
                for (auto &c : dl->chunks)
                    if (c == 1) c = 0;
                dl->bytes = DoneBytesLocked(*dl, total);
                dl->mode = "chunked";
            }
            oc = RunChunked(dl, fd, total, dest_is_html, err);
            if (oc == OC_FALLBACK_STREAM)
            {
                // continue sequentially after the contiguous prefix
                uint64_t prefix = 0;
                {
                    std::lock_guard<std::mutex> lk(dl->mu);
                    size_t i = 0;
                    while (i < dl->chunks.size() && dl->chunks[i] == 2) i++;
                    prefix = std::min<uint64_t>(total, (uint64_t)i * dl->chunk_size);
                    dl->chunks.clear();
                    dl->chunk_size = 0;
                }
                Trunc(fd, (off_t)prefix);
                Log("dl %u: server ignores Range, continuing with a single connection", dl->uid);
                use_stream = true;
                have_tmp = prefix;
                pr.range = false; // do not send Range for the remainder
                if (prefix > 0) pr.range = true; // resume from the prefix is still attempted; the restart path handles a 200 answer
            }
        }
        if (use_stream)
        {
            dl->mode = "single";
            {
                std::lock_guard<std::mutex> lk(dl->mu);
                dl->chunks.clear();
                dl->chunk_size = 0;
            }
            uint64_t off = pr.range ? std::min(have_tmp, total ? total : have_tmp) : 0;
            if (off == 0) Trunc(fd, 0);
            else Trunc(fd, (off_t)off);
            bool needs_reset = false;
            oc = RunStream(dl, fd, off, pr.range, dest_is_html, total, err, needs_reset);
            if (needs_reset)
            {
                Trunc(fd, 0);
                dl->bytes = 0;
                oc = RunStream(dl, fd, 0, false, dest_is_html, total, err, needs_reset);
            }
            if (oc == OC_SUCCESS)
            {
                std::lock_guard<std::mutex> lk(g_mu);
                dl->file_size = total;
            }
        }

        if (oc != OC_SUCCESS)
        {
            close_fd();
            return oc;
        }

        // ------------- finalize -------------
        {
            std::lock_guard<std::mutex> lk(dl->fd_mu);
            fsync(dl->fd);
        }
        fstat(fd, &st);
        if (total && (uint64_t)st.st_size > total) Trunc(fd, (off_t)total);
        fstat(fd, &st);
        if (total && (uint64_t)st.st_size != total)
        {
            char m[160];
            snprintf(m, sizeof(m), "Final size check failed: %llu of %llu bytes", (unsigned long long)st.st_size, (unsigned long long)total);
            err = m;
            close_fd();
            std::lock_guard<std::mutex> lk(dl->mu);
            std::fill(dl->chunks.begin(), dl->chunks.end(), 0);
            return OC_RETRY;
        }
        close_fd();
        if (rename(tmp.c_str(), dl->dest_path.c_str()) != 0)
        {
            err = std::string("Could not move the finished file into place: ") + strerror(errno);
            return OC_FATAL;
        }
        dl->bytes = total ? total : (uint64_t)st.st_size;
        return OC_SUCCESS;
    }

    static Outcome RunLegacy(const DownloadPtr &dl, std::string &err)
    {
        if (!g_hooks.legacy_get)
        {
            err = "This download type is not supported";
            return OC_FATAL;
        }
        std::lock_guard<std::mutex> lk(g_legacy_mu); // legacy clients share global progress pointers
        if (dl->stop.load()) return OC_STOPPED;
        LegacyJob job;
        {
            std::lock_guard<std::mutex> lk2(dl->mu);
            job.host = dl->host;
            job.src_path = dl->src_path;
        }
        job.tmp_path = dl->dest_path + ".tmp";
        MkDirsP(DirName(dl->dest_path));
        struct stat st;
        job.offset = (stat(job.tmp_path.c_str(), &st) == 0) ? (uint64_t)st.st_size : 0;
        dl->legacy_bytes = job.offset;
        job.progress = &dl->legacy_bytes;
        job.cancel = reinterpret_cast<const volatile bool *>(&dl->stop);
        dl->mode = "legacy";
        int ok = g_hooks.legacy_get(job);
        if (dl->stop.load()) return OC_STOPPED;
        if (!ok)
        {
            err = job.error.empty() ? "Transfer failed" : job.error;
            return OC_RETRY;
        }
        if (rename(job.tmp_path.c_str(), dl->dest_path.c_str()) != 0)
        {
            err = std::string("Could not move the finished file into place: ") + strerror(errno);
            return OC_FATAL;
        }
        {
            std::lock_guard<std::mutex> lk3(g_mu);
            if (dl->file_size == 0) dl->file_size = dl->legacy_bytes;
        }
        dl->bytes = dl->legacy_bytes;
        return OC_SUCCESS;
    }

    static void RunDownload(DownloadPtr dl)
    {
        std::string err;
        Outcome oc;
        Settings S = SettingsCopy();
        if (S.notify_start) Notify("Started: " + BaseName(dl->dest_path));
        Log("dl %u start: %s", dl->uid, dl->dest_path.c_str());
        if (dl->host.type == g_hooks.filehost_type) oc = RunHttp(dl, err);
        else oc = RunLegacy(dl, err);

        std::string note;
        bool notify_ok = false, notify_fail = false;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            int reason = dl->stop_reason.load();
            if (oc == OC_STOPPED && reason == SR_NONE) reason = SR_PAUSE;
            switch (oc)
            {
            case OC_SUCCESS:
                dl->state = ST_SUCCESS;
                dl->failed_attempts = 0;
                dl->error.clear();
                dl->paused_flag = dl->needs_link_flag = false;
                notify_ok = true;
                break;
            case OC_STOPPED:
                if (reason == SR_PAUSE) dl->state = ST_PAUSED;
                else dl->state = ST_PENDING; // rest mode, shutdown, relink: continue later
                break;
            case OC_NEEDS_LINK:
                dl->state = ST_NEEDS_LINK;
                dl->error = err;
                dl->failed_attempts = g_set.max_attempts;
                notify_fail = true;
                break;
            case OC_FATAL:
                dl->state = ST_FAILED;
                dl->error = err;
                dl->failed_attempts = g_set.max_attempts;
                notify_fail = true;
                break;
            case OC_RETRY:
            default:
                dl->failed_attempts++;
                dl->error = err;
                dl->state = ST_FAILED;
                dl->next_try_ms = NowMs() + std::min<uint64_t>(60, 5ull * dl->failed_attempts) * 1000;
                if (dl->failed_attempts >= g_set.max_attempts) notify_fail = true;
                break;
            }
            dl->conns = 0;
            dl->speed = 0;
            note = dl->error;
            if (dl->pending_delete)
            {
                std::string tmp = dl->dest_path + ".tmp";
                bool finished = dl->state == ST_SUCCESS;
                if (dl->delete_files)
                {
                    unlink(tmp.c_str());
                    if (finished) unlink(dl->dest_path.c_str());
                }
                dl->mgr.detach(); // nobody will join an erased download
                for (size_t i = 0; i < g_list.size(); i++)
                    if (g_list[i].get() == dl.get())
                    {
                        g_list.erase(g_list.begin() + (long)i);
                        break;
                    }
            }
            dl->running = false; // last use of g_mu by this thread
            g_dirty = true;
        }
        Log("dl %u end: outcome=%d %s", dl->uid, (int)oc, note.c_str());
        if (notify_ok && S.notify_complete) Notify("Completed: " + BaseName(dl->dest_path));
        if (notify_fail && S.notify_fail) Notify("Failed: " + BaseName(dl->dest_path) + (note.empty() ? "" : " - " + note));
    }

    // =====================================================================================================
    // scheduler
    // =====================================================================================================
    static void SchedulerLoop()
    {
        uint64_t last_save = NowMs();
        uint64_t last_speed = NowMs();
        while (g_run.load())
        {
            usleep(300 * 1000);
            uint64_t now = NowMs();
            {
                std::lock_guard<std::mutex> lk(g_mu);
                int active = 0;
                for (auto &d : g_list)
                {
                    if (!d->running && d->mgr.joinable()) d->mgr.join();
                    if (d->running) active++;
                }
                for (auto &d : g_list)
                {
                    int st = d->state.load();
                    if (st == ST_FAILED && !d->running && d->failed_attempts < g_set.max_attempts && now >= d->next_try_ms)
                    {
                        d->state = ST_PENDING;
                        g_dirty = true;
                    }
                }
                if (!g_rest.load())
                {
                    for (auto &d : g_list)
                    {
                        if (active >= g_set.max_parallel) break;
                        if (d->state.load() != ST_PENDING || d->running || d->mgr.joinable() || d->pending_delete) continue;
                        d->stop = false;
                        d->stop_reason = SR_NONE;
                        d->running = true;
                        d->state = d->bytes.load() > 0 ? ST_RESUMED : ST_DOWNLOADING;
                        d->error.clear();
                        DownloadPtr dp = d;
                        if (!d->mgr.start([dp]() { RunDownload(dp); }))
                        {
                            d->running = false;
                            d->state = ST_FAILED;
                            d->error = "Could not start a thread";
                            continue;
                        }
                        active++;
                        g_dirty = true;
                    }
                }
            }
            if (now - last_speed >= 1000)
            {
                std::lock_guard<std::mutex> lk(g_mu);
                for (auto &d : g_list)
                {
                    uint64_t b = (d->host.type == g_hooks.filehost_type) ? d->bytes.load() : d->legacy_bytes;
                    if (d->running)
                    {
                        double dt = (now - d->speed_ms) / 1000.0;
                        if (dt > 0 && d->speed_ms)
                        {
                            double inst = b >= d->speed_bytes ? (double)(b - d->speed_bytes) / dt : 0;
                            d->speed = d->speed * 0.6 + inst * 0.4;
                        }
                    }
                    else
                        d->speed = 0;
                    d->speed_bytes = b;
                    d->speed_ms = now;
                }
                last_speed = now;
            }
            bool any_active = false;
            {
                std::lock_guard<std::mutex> lk(g_mu);
                for (auto &d : g_list)
                    if (d->running) any_active = true;
            }
            if ((g_dirty.load() && now - last_save >= 1000) || (any_active && now - last_save >= 10000))
            {
                g_dirty = false;
                SaveNow();
                last_save = now;
            }
        }
    }

    // =====================================================================================================
    // public control API
    // =====================================================================================================
    void Init(const std::string &data_dir, const Hooks &hooks)
    {
        g_dir = data_dir;
        g_hist_path = data_dir + "/bg_download_history.json";
        g_set_path = data_dir + "/dlserver_settings.json";
        g_log_path = data_dir + "/dlserver.log";
        g_hooks = hooks;
        MkDirsP(g_dir);
    }

    void Start()
    {
        LoadSettings();
        LoadHistory();
        g_run = true;
        g_sched.start([]() { SchedulerLoop(); });
        Log("download engine %s started (%d downloads loaded)", kVersion, (int)g_list.size());
    }

    static void StopAll(int reason)
    {
        std::lock_guard<std::mutex> lk(g_mu);
        for (auto &d : g_list)
            if (d->running)
            {
                d->stop_reason = reason;
                d->stop = true;
                d->state = ST_STOPPING;
            }
    }

    void Shutdown()
    {
        if (!g_run.load()) return;
        StopAll(SR_SHUTDOWN);
        // wait for the managers
        for (int i = 0; i < 100; i++)
        {
            bool any = false;
            {
                std::lock_guard<std::mutex> lk(g_mu);
                for (auto &d : g_list)
                    if (d->running) any = true;
            }
            if (!any) break;
            usleep(100 * 1000);
        }
        g_run = false;
        g_sched.join();
        std::vector<DownloadPtr> snap;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            snap = g_list;
        }
        for (auto &d : snap)
            if (d->mgr.joinable()) d->mgr.join();
        SaveNow();
    }

    void SetRestMode(bool rest)
    {
        g_rest = rest;
        if (rest) StopAll(SR_REST);
        Log(rest ? "rest mode: downloads suspended" : "rest mode ended: downloads continue");
    }

    static bool BadDest(const std::string &p)
    {
        if (p.empty() || p[0] != '/') return true;
        size_t pos = 0;
        while (pos < p.size())
        {
            size_t e = p.find('/', pos);
            if (e == std::string::npos) e = p.size();
            if (p.substr(pos, e - pos) == "..") return true;
            pos = e + 1;
        }
        return p.back() == '/';
    }

    AddResult Add(const Host &host, const std::string &src_path, const std::string &dest_path, uint64_t size, uint64_t orig_id)
    {
        AddResult r;
        if (host.url.empty() || src_path.empty() || dest_path.empty())
        {
            r.error = "Required parameters are missing";
            return r;
        }
        if (BadDest(dest_path))
        {
            r.error = "Invalid destination path";
            return r;
        }
        std::lock_guard<std::mutex> lk(g_mu);
        for (auto &d : g_list)
        {
            if (d->dest_path != dest_path || d->pending_delete) continue;
            int st = d->state.load();
            if (st == ST_SUCCESS) continue; // a finished entry is replaced below
            // same destination: take the new link and continue where we stopped
            {
                std::lock_guard<std::mutex> lk2(d->mu);
                d->host = host;
                d->src_path = src_path;
                d->link_gen++;
            }
            if (size) d->file_size = std::max(d->file_size, size);
            if (!d->running)
            {
                d->failed_attempts = 0;
                d->next_try_ms = 0;
                d->error.clear();
                d->state = ST_PENDING;
            }
            else if (d->state.load() == ST_STOPPING && d->stop_reason.load() == SR_PAUSE)
            {
                d->stop_reason = SR_RELINK;
            }
            g_dirty = true;
            r.ok = true;
            r.updated = true;
            r.uid = d->uid;
            Log("dl %u: link updated for %s", d->uid, dest_path.c_str());
            return r;
        }
        for (size_t i = 0; i < g_list.size(); i++)
            if (g_list[i]->dest_path == dest_path && g_list[i]->state.load() == ST_SUCCESS && !g_list[i]->running)
            {
                g_list.erase(g_list.begin() + (long)i);
                break;
            }
        auto d = std::make_shared<Download>();
        d->uid = g_next_uid++;
        d->orig_id = orig_id ? orig_id : d->uid;
        d->host = host;
        d->src_path = src_path;
        d->dest_path = dest_path;
        d->file_size = size > (1ull << 42) ? 0 : size; // the client may pass garbage when it could not read the size
        d->timestamp = WallUs();
        d->state = ST_PENDING;
        g_list.push_back(d);
        g_dirty = true;
        r.ok = true;
        r.uid = d->uid;
        Log("dl %u queued: %s", d->uid, dest_path.c_str());
        return r;
    }

    static DownloadPtr FindLocked(uint32_t uid)
    {
        for (auto &d : g_list)
            if (d->uid == uid && !d->pending_delete) return d;
        return nullptr;
    }

    bool Pause(uint32_t uid, std::string &err)
    {
        std::lock_guard<std::mutex> lk(g_mu);
        DownloadPtr d = FindLocked(uid);
        if (!d)
        {
            err = "No such download";
            return false;
        }
        int st = d->state.load();
        if (st == ST_SUCCESS)
        {
            err = "Already finished";
            return false;
        }
        if (d->running)
        {
            d->stop_reason = SR_PAUSE;
            d->stop = true;
            d->state = ST_STOPPING;
        }
        else
            d->state = ST_PAUSED;
        d->speed = 0;
        g_dirty = true;
        return true;
    }

    bool Resume(uint32_t uid, std::string &err)
    {
        std::lock_guard<std::mutex> lk(g_mu);
        DownloadPtr d = FindLocked(uid);
        if (!d)
        {
            err = "No such download";
            return false;
        }
        int st = d->state.load();
        if (st == ST_SUCCESS)
        {
            err = "Already finished";
            return false;
        }
        if (d->running)
        {
            if (st == ST_STOPPING && d->stop_reason.load() == SR_PAUSE) d->stop_reason = SR_RELINK; // restart as soon as it stops
            return true;
        }
        d->failed_attempts = 0;
        d->next_try_ms = 0;
        d->error.clear();
        d->state = ST_PENDING;
        g_dirty = true;
        return true;
    }

    bool Remove(uint32_t uid, bool delete_files, std::string &err)
    {
        std::lock_guard<std::mutex> lk(g_mu);
        DownloadPtr d = FindLocked(uid);
        if (!d)
        {
            err = "No such download";
            return false;
        }
        d->delete_files = delete_files;
        if (d->running)
        {
            d->pending_delete = true;
            d->stop_reason = SR_DELETE;
            d->stop = true;
            d->state = ST_STOPPING;
        }
        else
        {
            if (d->mgr.joinable()) d->mgr.join();
            if (delete_files)
            {
                unlink((d->dest_path + ".tmp").c_str());
                if (d->state.load() == ST_SUCCESS) unlink(d->dest_path.c_str());
            }
            for (size_t i = 0; i < g_list.size(); i++)
                if (g_list[i].get() == d.get())
                {
                    g_list.erase(g_list.begin() + (long)i);
                    break;
                }
        }
        g_dirty = true;
        Log("dl %u removed (delete_files=%d)", uid, (int)delete_files);
        return true;
    }

    int PauseAll()
    {
        std::vector<uint32_t> ids;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            for (auto &d : g_list)
                if (d->state.load() != ST_SUCCESS) ids.push_back(d->uid);
        }
        int n = 0;
        std::string e;
        for (auto id : ids)
            if (Pause(id, e)) n++;
        return n;
    }
    int ResumeAll()
    {
        std::vector<uint32_t> ids;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            for (auto &d : g_list)
            {
                int st = d->state.load();
                if (st == ST_PAUSED || st == ST_FAILED || st == ST_NEEDS_LINK) ids.push_back(d->uid);
            }
        }
        int n = 0;
        std::string e;
        for (auto id : ids)
            if (Resume(id, e)) n++;
        return n;
    }

    // =====================================================================================================
    // reporting
    // =====================================================================================================
    mj::Json ListJson(bool legacy)
    {
        mj::Json arr = mj::Json::array();
        std::lock_guard<std::mutex> lk(g_mu);
        for (auto &d : g_list)
        {
            if (d->pending_delete) continue;
            int st = d->state.load();
            bool is_http = d->host.type == g_hooks.filehost_type;
            uint64_t bytes = is_http ? d->bytes.load() : d->legacy_bytes;
            if (st == ST_SUCCESS && d->file_size) bytes = d->file_size;
            mj::Json e = mj::Json::object();
            if (legacy)
            {
                e.set("path", mj::Json::str(d->dest_path));
                e.set("bytes_transfered", mj::Json::num((int64_t)bytes));
                e.set("file_size", mj::Json::num((int64_t)d->file_size));
                e.set("state", mj::Json::num(LegacyStateOf(st)));
                e.set("timestamp", mj::Json::num((int64_t)(d->timestamp / 1000000)));
            }
            else
            {
                e.set("id", mj::Json::num(d->uid));
                e.set("path", mj::Json::str(d->dest_path));
                e.set("name", mj::Json::str(BaseName(d->dest_path)));
                e.set("bytes", mj::Json::num((int64_t)bytes));
                e.set("size", mj::Json::num((int64_t)d->file_size));
                e.set("state", mj::Json::num(st));
                e.set("state_name", mj::Json::str(kStateNames[st]));
                e.set("speed", mj::Json::num((int64_t)d->speed));
                int64_t eta = -1;
                if (d->speed > 1 && d->file_size > bytes) eta = (int64_t)((d->file_size - bytes) / d->speed);
                e.set("eta", mj::Json::num(eta));
                e.set("connections", mj::Json::num(d->conns.load()));
                e.set("mode", mj::Json::str(d->mode));
                e.set("attempts", mj::Json::num(d->failed_attempts));
                e.set("error", mj::Json::str(d->error));
                e.set("timestamp", mj::Json::num((int64_t)(d->timestamp / 1000000)));
                e.set("type", mj::Json::num(d->host.type));
            }
            arr.push(e);
        }
        return arr;
    }

    mj::Json InfoJson()
    {
        mj::Json j = mj::Json::object();
        Settings s;
        int active = 0, total = 0;
        {
            std::lock_guard<std::mutex> lk(g_mu);
            s = g_set;
            for (auto &d : g_list)
            {
                total++;
                if (d->running) active++;
            }
        }
        j.set("name", mj::Json::str("ps4-dlserver"));
        j.set("version", mj::Json::str(kVersion));
        j.set("compat_version", mj::Json::str(kCompatVersion));
        j.set("api", mj::Json::num(2));
        j.set("downloads", mj::Json::num(total));
        j.set("active", mj::Json::num(active));
        j.set("connections", mj::Json::num(g_total_conns.load()));
        j.set("rest_mode", mj::Json::boolean(g_rest.load()));
        j.set("disk_free", mj::Json::num(FreeBytes(g_dir)));
        mj::Json st = mj::Json::object();
        st.set("max_parallel", mj::Json::num(s.max_parallel));
        st.set("max_conns_per_download", mj::Json::num(s.max_conns_per_download));
        st.set("max_total_conns", mj::Json::num(s.max_total_conns));
        st.set("auto_conns", mj::Json::boolean(s.auto_conns));
        st.set("fixed_conns", mj::Json::num(s.fixed_conns));
        st.set("chunk_mb", mj::Json::num(s.chunk_mb));
        st.set("max_attempts", mj::Json::num(s.max_attempts));
        st.set("notify_start", mj::Json::boolean(s.notify_start));
        st.set("notify_complete", mj::Json::boolean(s.notify_complete));
        st.set("notify_fail", mj::Json::boolean(s.notify_fail));
        st.set("token_set", mj::Json::boolean(!s.token.empty()));
        j.set("settings", st);
        return j;
    }

    Settings GetSettings() { return SettingsCopy(); }

    bool UpdateSettings(const mj::Json &j, std::string &err)
    {
        if (j.t != mj::Json::Obj)
        {
            err = "Expected a JSON object";
            return false;
        }
        {
            std::lock_guard<std::mutex> lk(g_mu);
            ApplySettings(j, g_set);
        }
        SaveSettings();
        return true;
    }
}
