#!/usr/bin/env python3
import json, os, shutil, signal, subprocess, sys, time, urllib.request, tempfile
sys.path.insert(0, os.path.dirname(__file__))
import origin as O

HOST = "http://127.0.0.1:7701"
BIN = sys.argv[1]
PER, TOTAL = sys.argv[2], sys.argv[3]
work = tempfile.mkdtemp(prefix="dltest")
data = os.path.join(work, "data"); out = os.path.join(work, "out")
os.makedirs(data); os.makedirs(out)
procs = []

def start_origin():
    p = subprocess.Popen([sys.executable, os.path.join(os.path.dirname(__file__), "origin.py"), "7702", PER, TOTAL]); procs.append(p); time.sleep(1.0); return p
def start_server():
    p = subprocess.Popen([BIN, data, "7701"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True); procs.append(p); time.sleep(0.8); return p
def stop(p):
    p.send_signal(signal.SIGTERM)
    try: p.wait(10)
    except Exception: p.kill()
def req(path, body=None, method=None):
    r = urllib.request.Request(HOST + path, data=(json.dumps(body).encode() if body is not None else None), method=method)
    try:
        with urllib.request.urlopen(r, timeout=10) as f: return f.status, f.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
def jreq(path, body=None):
    s, t = req(path, body, "POST" if body is not None else None)
    return s, json.loads(t) if t.strip().startswith(("{", "[")) else t
def add(name, urlpath, size_mb=0, legacy=False):
    body = {"type": 7, "url": "http://127.0.0.1:7702", "src_path": urlpath, "dest_path": os.path.join(out, name), "size": size_mb << 20, "id": 1}
    return jreq("/download_url" if legacy else "/v2/add", body)
def dls(): return jreq("/v2/downloads")[1]["downloads"]
def get(i): 
    for d in dls():
        if d["id"] == i: return d
def wait(i, states, timeout):
    t0 = time.time()
    while time.time() - t0 < timeout:
        d = get(i)
        if d and d["state_name"] in states: return d, time.time() - t0
        time.sleep(0.4)
    return get(i), time.time() - t0
def verify(path, size_mb):
    size = size_mb << 20
    if os.path.getsize(path) != size: return "size %d != %d" % (os.path.getsize(path), size)
    with open(path, "rb") as f:
        off = 0
        while off < size:
            n = min(1 << 20, size - off)
            if f.read(n) != O.content(off, n): return "content mismatch near byte %d" % off
            off += n
    return "OK"
results = []
def report(name, ok, detail=""):
    results.append(ok); print(("PASS " if ok else "FAIL ") + name + ("  -> " + detail if detail else ""), flush=True)

try:
    start_origin(); srv = start_server()
    print("per-connection cap %s MB/s, shared pipe %s MB/s" % (PER, TOTAL))

    # 1. info + legacy compat
    s, info = jreq("/v2/info"); report("info endpoint", s == 200 and info["api"] == 2, info["version"])
    s, t = req("/version"); report("legacy /version returns compat string", t == "1.05", t)

    # 2. baseline: single connection forced
    jreq("/v2/settings", {"auto_conns": False, "fixed_conns": 1, "max_conns_per_download": 1})
    s, r = add("single.bin", "/f?size=96", 96); i = r["id"]
    d, took1 = wait(i, ("done", "failed", "needs_link"), 120)
    report("single connection 96MB", d["state_name"] == "done" and verify(os.path.join(out, "single.bin"), 96) == "OK", "%.1fs (%.1f MB/s) mode=%s" % (took1, 96 / took1, d["mode"]))

    # 3. automatic mode
    jreq("/v2/settings", {"auto_conns": True, "max_conns_per_download": 8})
    s, r = add("auto.bin", "/f?size=192", 192); i = r["id"]
    peak = 0; t0 = time.time()
    while time.time() - t0 < 150:
        d = get(i); peak = max(peak, d["connections"])
        if d["state_name"] in ("done", "failed", "needs_link"): break
        time.sleep(0.4)
    took = time.time() - t0
    v = verify(os.path.join(out, "auto.bin"), 192)
    report("auto connections 192MB", d["state_name"] == "done" and v == "OK" and peak >= 4, "%.1fs (%.1f MB/s), peak %d connections, integrity %s; single was %.1f MB/s" % (took, 192 / took, peak, v, 96 / took1))

    # 4. pause / resume mid-download keeps data
    s, r = add("pause.bin", "/f?size=160", 160); i = r["id"]
    time.sleep(6); st, _ = jreq("/v2/pause", {"id": i}); d, _ = wait(i, ("paused",), 15)
    b1 = d["bytes"]; time.sleep(2); b2 = get(i)["bytes"]
    report("pause stops traffic", d["state_name"] == "paused" and b1 == b2 and 0 < b1 < (160 << 20), "bytes=%d" % b1)
    jreq("/v2/resume", {"id": i}); d, _ = wait(i, ("done", "failed"), 120)
    report("resume completes with correct data", d["state_name"] == "done" and verify(os.path.join(out, "pause.bin"), 160) == "OK")

    # 5. delete a running download without touching another one
    s, r1 = add("keep.bin", "/f?size=128", 128); s, r2 = add("kill.bin", "/f?size=128", 128)
    time.sleep(1.5)
    jreq("/v2/delete", {"id": r2["id"], "delete_files": True})
    time.sleep(1.5)
    ids = [x["id"] for x in dls()]
    report("delete one running download", r2["id"] not in ids and not os.path.exists(os.path.join(out, "kill.bin.tmp")) and not os.path.exists(os.path.join(out, "kill.bin")) )
    d, _ = wait(r1["id"], ("done", "failed"), 120)
    report("other download unaffected", d["state_name"] == "done" and verify(os.path.join(out, "keep.bin"), 128) == "OK")

    # 6. server without Range
    s, r = add("norange.bin", "/norange?size=40", 40); i = r["id"]
    d, took = wait(i, ("done", "failed", "needs_link"), 120)
    report("server ignoring Range (stream mode)", d["state_name"] == "done" and verify(os.path.join(out, "norange.bin"), 40) == "OK", "mode=" + d["mode"])

    # 7. html instead of file
    s, r = add("page.bin", "/html", 50); d, _ = wait(r["id"], ("needs_link", "failed", "done"), 20)
    report("web page instead of file is rejected", d["state_name"] == "needs_link" and not os.path.exists(os.path.join(out, "page.bin")), d["error"][:70])

    # 8. expired link, then re-send link with same destination
    s, r = add("exp.bin", "/expired?size=48", 48); d, _ = wait(r["id"], ("needs_link", "failed"), 20)
    ok1 = d["state_name"] == "needs_link"
    s, r2 = add("exp.bin", "/f?size=48", 48)
    d, _ = wait(r["id"], ("done", "failed", "needs_link"), 60)
    report("expired link then re-sent link continues", ok1 and r2.get("updated") and d["state_name"] == "done" and verify(os.path.join(out, "exp.bin"), 48) == "OK")

    # 9. host that refuses parallel requests -> falls back to 1 connection
    s, r = add("refuse.bin", "/refuse_parallel?size=80", 80); d, took = wait(r["id"], ("done", "failed", "needs_link"), 120)
    report("host refusing parallel connections", d["state_name"] == "done" and verify(os.path.join(out, "refuse.bin"), 80) == "OK", "%.1fs" % took)

    # 10. flaky connection (drops mid-chunk)
    s, r = add("flaky.bin", "/flaky?size=96", 96); d, took = wait(r["id"], ("done", "failed", "needs_link"), 180)
    report("flaky connection recovers", d["state_name"] == "done" and verify(os.path.join(out, "flaky.bin"), 96) == "OK", "%.1fs" % took)

    # 11. kill the server mid-download, restart, it resumes from disk
    s, r = add("crash.bin", "/f?size=160", 160); i = r["id"]; time.sleep(7)
    b_before = get(i)["bytes"]
    srv.kill(); srv.wait(); time.sleep(0.5)
    srv = start_server(); time.sleep(1.5)
    d = get(i); b_after_start = d["bytes"]
    d, _ = wait(i, ("done", "failed"), 150)
    report("hard kill then resume", d is not None and d["state_name"] == "done" and verify(os.path.join(out, "crash.bin"), 160) == "OK", "had %.0fMB before kill, restarted from ~%.0fMB" % (b_before / 1048576, b_after_start / 1048576))

    # 12. corrupt history file does not crash the server
    stop(srv); open(os.path.join(data, "bg_download_history.json"), "w").write("{ this is not json [[[")
    for f in ("bg_download_history.json.bak",):
        p = os.path.join(data, f)
        if os.path.exists(p): os.remove(p)
    srv = start_server(); s, _ = req("/get_download_state")
    report("corrupt history file survives startup", s == 200 and srv.poll() is None)

    # 13. legacy route + legacy state list shape
    s, r = add("legacy.bin", "/f?size=8", 8, legacy=True); time.sleep(3)
    s, t = req("/get_download_state"); L = json.loads(t)
    item = [x for x in L if x["path"].endswith("legacy.bin")]
    report("legacy /download_url + /get_download_state", s == 200 and item and set(item[0]) == {"path", "bytes_transfered", "file_size", "state", "timestamp"} and item[0]["state"] == 4, json.dumps(item[0]) if item else "missing")

    # 14. bad requests
    s, _ = req("/download_url", {"type": 7}, "POST"); report("invalid add is rejected with HTTP 400", s == 400, str(s))
    s, _ = req("/v2/pause", {"id": 999}, "POST"); report("unknown id gives 404", s == 404, str(s))

    # ================= abdo6 additions =================
    def req2(path, body=None, method=None, headers=None):
        r = urllib.request.Request(HOST + path, data=(json.dumps(body).encode() if body is not None else None), method=method)
        for k, v in (headers or {}).items(): r.add_header(k, v)
        try:
            with urllib.request.urlopen(r, timeout=10) as f: return f.status, f.read().decode()
        except urllib.error.HTTPError as e: return e.code, e.read().decode()
    def names(): return {x["id"]: x for x in dls()}
    def clear_all():
        for x in dls(): jreq("/v2/delete", {"id": x["id"], "delete_files": True})
        time.sleep(1.5)
    def poll_done(ids, timeout):
        t0 = time.time(); done_at = {}
        while time.time() - t0 < timeout and len(done_at) < len(ids):
            n = names()
            for i in ids:
                if i not in done_at and i in n and n[i]["state_name"] == "done": done_at[i] = time.time() - t0
            time.sleep(0.25)
        return done_at

    clear_all()
    jreq("/v2/settings", {"max_parallel": 1, "auto_conns": False, "fixed_conns": 1, "max_conns_per_download": 1, "preempt": True, "dest_roots": []})

    # 15. version string comes from the build (CMake), not from a hard-coded constant
    s, info = jreq("/v2/info"); report("version comes from the build define", info["version"] == os.environ.get("EXPECT_VERSION", "test"), info["version"])

    # 16. priority decides which queued download starts next
    s, a = add("p_a.bin", "/f?size=40", 40); s, b = add("p_b.bin", "/f?size=16", 16); s, c = add("p_c.bin", "/f?size=16", 16)
    time.sleep(1.0)
    st, _ = jreq("/v2/priority", {"id": c["id"], "priority": 5})
    t = poll_done([a["id"], b["id"], c["id"]], 90)
    report("higher priority starts before an older queued download", st == 200 and len(t) == 3 and t[c["id"]] < t[b["id"]], "order: " + ", ".join("%s=%.0fs" % (k, v) for k, v in sorted(t.items(), key=lambda kv: kv[1])))
    report("priority is reported by /v2/downloads", names()[c["id"]]["priority"] == 5 and names()[b["id"]]["priority"] == 0)
    clear_all()

    # 17. preemption: a high-priority download takes the slot of a long low-priority one, which then resumes and stays intact
    s, lo = add("pre_lo.bin", "/f?size=120", 120)
    time.sleep(23)  # past the 20 s grace period
    bytes_before = get(lo["id"])["bytes"]
    s, hi = add("pre_hi.bin", "/f?size=8", 8)
    jreq("/v2/priority", {"id": hi["id"], "priority": 10})
    th = poll_done([hi["id"]], 40)
    lo_state = get(lo["id"])["state_name"]
    report("high priority preempts a running low-priority download", hi["id"] in th and lo_state != "done", "hi done after %.0fs, lo=%s (had %.0f MB)" % (th.get(hi["id"], -1), lo_state, bytes_before / 1048576))
    tl = poll_done([lo["id"]], 120)
    report("preempted download resumes with intact data", lo["id"] in tl and verify(os.path.join(out, "pre_lo.bin"), 120) == "OK")
    clear_all()

    # 18. queue order: move top / bottom / up / down / pos
    ids = []
    for n in ("m_x.bin", "m_y.bin", "m_z.bin"):
        s, r = add(n, "/f?size=64", 64); ids.append(r["id"]); jreq("/v2/pause", {"id": r["id"]})
    X, Y, Z = ids
    def order(): return [i for i in [x["id"] for x in dls()] if i in ids]
    ok = order() == [X, Y, Z]
    jreq("/v2/move", {"id": Z, "to": "top"}); ok = ok and order() == [Z, X, Y]
    jreq("/v2/move", {"id": Z, "to": "bottom"}); ok = ok and order() == [X, Y, Z]
    jreq("/v2/move", {"id": X, "to": "down"}); ok = ok and order() == [Y, X, Z]
    jreq("/v2/move", {"id": Z, "to": "up"}); ok = ok and order() == [Y, Z, X]
    s, r = jreq("/v2/move", {"id": X, "to": "pos", "position": 0}); ok = ok and order() == [X, Y, Z] and r.get("position") == 0
    s2, _ = jreq("/v2/move", {"id": 99999, "to": "top"}); s3, _ = jreq("/v2/move", {"id": X, "to": "sideways"})
    report("move top/bottom/up/down/pos", ok and s2 == 404 and s3 == 400, "order=%s" % order())
    # the order survives a restart
    stop(srv); srv = start_server(); time.sleep(1.0)
    report("queue order and priority survive a restart", order() == [X, Y, Z])
    clear_all()

    # 19. start_now: top of queue + preemption
    s, lo = add("sn_lo.bin", "/f?size=120", 120)
    time.sleep(23)
    s, q = add("sn_q.bin", "/f?size=8", 8)
    s, _ = jreq("/v2/start_now", {"id": q["id"]})
    tq = poll_done([q["id"]], 40)
    report("start_now runs the download immediately", s == 200 and q["id"] in tq and get(lo["id"])["state_name"] != "done" and get(q["id"])["priority"] >= 1, "%.0fs" % tq.get(q["id"], -1))
    clear_all()

    # 20. browser (CSRF) guard and token
    body = {"type": 7, "url": "http://127.0.0.1:7702", "src_path": "/f?size=1", "dest_path": os.path.join(out, "csrf.bin"), "size": 1 << 20}
    s1, _ = req2("/v2/add", body, "POST", {"Origin": "http://evil.example"})
    s2, _ = req2("/download_url", body, "POST", {"Origin": "null"})
    s3, _ = req2("/v2/info", None, None, {"Sec-Fetch-Site": "cross-site"})
    s4, _ = req2("/v2/info", None, None, {"Sec-Fetch-Site": "same-origin"})
    s5, _ = req2("/v2/info", None, None, {"Origin": "http://127.0.0.1:7701"})
    s6, _ = req2("/v2/info")
    report("cross-site browser requests are rejected, native clients are not", (s1, s2, s3, s4, s5, s6) == (403, 403, 403, 200, 200, 200) and not os.path.exists(os.path.join(out, "csrf.bin")), str((s1, s2, s3, s4, s5, s6)))
    jreq("/v2/settings", {"token": "s3cret"})
    a1, _ = req2("/v2/info"); a2, _ = req2("/v2/info", None, None, {"X-Token": "wrong"}); a3, _ = req2("/v2/info", None, None, {"X-Token": "s3cret"})
    a4, _ = req2("/stop", None, None, None)
    a5, _ = req2("/v2/priority", {"id": 1, "priority": 1}, "POST")
    report("token protects /v2 routes and /stop", (a1, a2, a3, a4, a5) == (401, 401, 200, 401, 401), str((a1, a2, a3, a4, a5)))
    s, _ = req2("/v2/settings", {"token": ""}, "POST", {"X-Token": "s3cret"}); a6, _ = req2("/v2/info")
    report("token can be removed with the token", s == 200 and a6 == 200)

    # 21. destination allow-list
    jreq("/v2/settings", {"dest_roots": [out]})
    s, r1 = add("allowed.bin", "/f?size=1", 1); s2, r2 = jreq("/v2/add", {"type": 7, "url": "http://127.0.0.1:7702", "src_path": "/f?size=1", "dest_path": "/tmp/elsewhere/x.bin", "size": 1 << 20})
    s3, r3 = jreq("/v2/add", {"type": 7, "url": "http://127.0.0.1:7702", "src_path": "/f?size=1", "dest_path": out + "-evil/x.bin", "size": 1 << 20})
    report("dest_roots rejects other folders (and look-alike prefixes)", s == 200 and s2 == 400 and s3 == 400 and "not allowed" in r2.get("error", ""), r2.get("error", ""))
    jreq("/v2/settings", {"dest_roots": []})
    s, r = jreq("/v2/add", {"type": 7, "url": "http://127.0.0.1:7702", "src_path": "/f?size=1", "dest_path": os.path.join(out, "free.bin"), "size": 1 << 20})
    report("dest_roots empty allows any absolute path again", s == 200)
    clear_all()

    # 22. two legacy (FTP/SMB/NFS style) downloads run one at a time and the second must not hold a slot
    jreq("/v2/settings", {"max_parallel": 2, "auto_conns": False, "fixed_conns": 1, "max_conns_per_download": 1})
    LB = {"type": 1, "url": "ftp://x", "src_path": "/a", "size": 6}
    s, l1 = jreq("/v2/add", dict(LB, dest_path=os.path.join(out, "leg1.bin")))
    s, l2 = jreq("/v2/add", dict(LB, dest_path=os.path.join(out, "leg2.bin")))
    time.sleep(0.8)
    s, f = add("after_legacy.bin", "/f?size=8", 8)
    d, took = wait(f["id"], ("done",), 20)
    report("second legacy download does not block a free slot", d is not None and d["state_name"] == "done" and took < 5, "%.1fs" % took)
    tl = poll_done([l1["id"], l2["id"]], 40)
    report("legacy downloads finish one after the other", len(tl) == 2 and os.path.exists(os.path.join(out, "leg1.bin")) and os.path.exists(os.path.join(out, "leg2.bin")), "done at %s" % {k: round(v) for k, v in tl.items()})
    clear_all()
    jreq("/v2/settings", {"max_parallel": 2, "auto_conns": True, "max_conns_per_download": 8})

    stats = req("/stats".replace("/stats", ""))  # placeholder to keep flake8 quiet
finally:
    for p in procs:
        try: p.kill()
        except Exception: pass
    print("log tail:\n" + "")
    try:
        print(open(os.path.join(data, "dlserver.log")).read()[-2500:])
    except Exception: pass
    shutil.rmtree(work, ignore_errors=True)
print("\n%d/%d passed" % (sum(results), len(results)))
sys.exit(0 if all(results) else 1)
