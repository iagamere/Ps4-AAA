# ezRemote Server (custom build 2.0.0-abdo1)

نسخة معدّلة من سيرفر ezRemote الخلفي (المنفذ 6701): محرك تحميل جديد + API جديد، مع بقاء توافقه الكامل مع
ezRemote Client الأصلي وتطبيق PS4Monitor الحالي.

## ما الجديد

| | الأصلي | هذه النسخة |
|---|---|---|
| التحميل | اتصال واحد، طابور متسلسل | تلقائي: يبدأ باتصال واحد ويزيد الاتصالات ما دامت السرعة ترتفع (حتى 8)، وطابور متوازٍ (2 افتراضياً) |
| إيقاف/حذف تحميل واحد | غير ممكن (إيقاف السيرفر كله وتعديل JSON) | `/v2/pause` و`/v2/resume` و`/v2/delete` لكل تحميل بمعرّفه دون المساس بغيره |
| «اكتمل» | يكفي نجاح الاتصال | فحص كود HTTP ونوع المحتوى والحجم النهائي قبل إعلان النجاح |
| ملف السجل | كتابة غير ذرّية، التلف يُسقط السيرفر | كتابة ذرّية + نسخة `.bak` + قراءة متسامحة |
| تعدد الخيوط | قائمة بلا قفل ومؤشر إلى عنصر في vector (تحطم محتمل) | قفل على القائمة وعناصر `shared_ptr` |
| رابط منتهٍ | محاولات عمياء | الحالة `needs_link`؛ أعد إرسال الرابط بنفس الوجهة فيكمل من حيث توقف |
| أمان | يقدّم جذر ملفات الـ PS4 كاملاً على الشبكة بلا مصادقة | أُزيل تقديم الملفات؛ رمز اختياري `X-Token` لمسارات `/v2` |
| التشغيل بعد ezRemote Client | — | إن كان السيرفر الأصلي يعمل، يستبدله الجديد تلقائياً عند تحميله من GoldHEN |

## التشغيل
1. حمّل `ezremote-server-2.0.0-abdo1.elf` من GoldHEN (Payload Loader / BinLoader). يمكن في أي وقت، قبل ezRemote Client أو بعده.
2. لا تضغط زر «إعادة تشغيل السيرفر» داخل ezRemote Client: يعيد تحميل السيرفر الأصلي المرفق في الـ pkg. إن حدث، حمّل هذا الملف مرة ثانية فيستبدله.

## الـ API
القديم دون تغيير في العقد: `POST /download_url`، `GET /get_download_state`، `GET /version` (يرجع `1.05` كي لا يعرض الكلاينت نافذة تحذير)، `GET /stop`، `/store_bg_install_data`، `/bg_install/<hash>`.

الجديد (JSON، رأس `X-Token` إن ضُبط رمز):
- `GET /v2/info` الإصدار، المساحة الحرة، الإعدادات، عدد الاتصالات
- `GET /v2/downloads` قائمة: `id, path, name, bytes, size, state, state_name, speed, eta, connections, mode, attempts, error`
- `POST /v2/add` نفس حقول `/download_url`
- `POST /v2/pause {"id":N}` أو `{"all":true}`
- `POST /v2/resume {"id":N}` (يعمل أيضاً كإعادة محاولة)
- `POST /v2/delete {"id":N,"delete_files":true}`
- `POST /v2/settings {"max_parallel":2,"max_conns_per_download":8,"auto_conns":true,"fixed_conns":4,"chunk_mb":16,"notify_start":false,"notify_complete":true,"notify_fail":true,"token":""}`
- `GET /v2/log?lines=100` سجل نصي للتشخيص (ملف `/data/ezremote-client/dlserver.log` أيضاً)

الحالات: `pending, downloading, resuming, failed, done, paused, needs_link, stopping`.
في `/get_download_state` القديمة تُعرض `paused` و`needs_link` كـ FAILED (3) و`stopping` كـ DOWNLOADING (1)، حتى لا يكسر الكلاينت الأصلي.

## ملاحظات وحدود (بصراحة)
- **لم يُبنَ ولم يُجرَّب على PS4.** المحرك (`source/dl/`) بُني واختُبر على لينكس (انظر `tests/`). الملفات المعدّلة التي تحتاج مكتبات الـ SDK (`server/http_server.cpp`، `main.cpp`، `clients/baseclient.cpp`، `config.*`) لم تُترجَم، وقد تظهر فيها أخطاء بناء.
- **الاستئناف بعد انقطاع مفاجئ** يرجع إلى آخر مقطع (16MB افتراضياً) مكتمل ومحفوظ، فقد يضيع جزء من التقدم (آخر ≤10 ثوانٍ ومقاطع قيد التنزيل).
- التحميل المتعدد الاتصالات والتحكم الكامل لتحميلات **file host** (ما يرسله تطبيقك عبر الكلاينت). أنواع FTP/SMB/NFS/SFTP/WebDAV/HTTP-server تبقى على الكود الأصلي، وتُنفَّذ **واحداً واحداً**، والإيقاف المؤقت لها قد ينتظر نهاية الملف الجاري (الإلغاء الفوري مدعوم لـ HTTP فقط).
- التحقق من الشهادات في HTTPS معطّل كما في الأصلي.
- حجم مجمّع خيوط HTTP تُرك 64 كما هو (لم أتحقق أنه آمن لخفضه مع تثبيت الحزم).
- `statfs` و`pthread_attr_setstacksize` و`pwrite` مستعملة ولم أتحقق من توفرها في libc الخاص بـ SDK الـ PS4.

## البناء
كما في المشروع الأصلي (`CMakeLists.txt` يشير إلى `/opt/ps4-payload-sdk`). أُضيف `source/dl/engine.cpp` و`source/dl/api.cpp`، وتبعيات json-c وssl كما هي.

## اختبار المنطق على لينكس
```
g++ -std=c++14 -O1 -Isource source/http/httplib.cpp source/dl/engine.cpp source/dl/api.cpp tests/test_main.cpp -lpthread -o dlserver_test
python3 tests/run_tests.py ./dlserver_test 4 40     # 4 MB/s لكل اتصال، 40 MB/s للأنبوب المشترك
```
الاختبارات: السرعة (واحد مقابل تلقائي)، سلامة البايتات، إيقاف/استئناف، حذف تحميل دون التأثير على آخر، خادم بلا Range،
صفحة HTML بدل ملف، رابط منتهٍ ثم إعادة إرساله، مضيف يرفض الاتصالات المتوازية، اتصال يقطع أثناء النقل،
قتل السيرفر ثم الاستئناف من القرص، ملف سجل تالف.
