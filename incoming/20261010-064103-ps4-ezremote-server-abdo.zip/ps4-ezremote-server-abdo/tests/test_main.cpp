// Linux test host: the download engine + its HTTP API, without any PS4 code.
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include "dl/api.h"
#include "dl/engine.h"

static httplib::Server *g_svr;
static void on_sig(int) { if (g_svr) g_svr->stop(); }

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: %s <data_dir> <port>\n", argv[0]); return 2; }
    signal(SIGINT, on_sig);
    signal(SIGTERM, on_sig);
    DL::Hooks h;
    h.notify = [](const std::string &m) { printf("NOTIFY: %s\n", m.c_str()); fflush(stdout); };
    DL::Init(argv[1], h);
    DL::Start();
    httplib::Server svr;
    g_svr = &svr;
    DL::RegisterRoutes(svr);
    svr.listen("127.0.0.1", atoi(argv[2]));
    DL::Shutdown();
    return 0;
}
